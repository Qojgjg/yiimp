﻿-- phpMyAdmin SQL Dump
-- version 4.6.0
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Dim 03 Avril 2016 à 14:29
-- Version du serveur :  10.1.13-MariaDB
-- Version de PHP :  7.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `yaamp`
--

-- --------------------------------------------------------

--
-- Structure de la table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(255) NOT NULL,
  `coinid` int(11) DEFAULT NULL,
  `last_earning` int(10) DEFAULT NULL,
  `is_locked` tinyint(1) DEFAULT '0',
  `no_fees` tinyint(1) DEFAULT NULL,
  `donation` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `logtraffic` tinyint(1) DEFAULT NULL,
  `balance` double DEFAULT '0',
  `username` varchar(40) NOT NULL,
  `coinsymbol` varchar(16) DEFAULT NULL,
  `login` varchar(45) DEFAULT NULL,
  `hostaddr` varchar(39) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `algos`
--

CREATE TABLE `algos` (
  `id` int(11) NOT NULL,
  `name` varchar(16) DEFAULT NULL,
  `profit` double DEFAULT NULL,
  `rent` double DEFAULT NULL,
  `factor` double DEFAULT NULL,
  `overflow` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `algos`
--

INSERT INTO `algos` (`id`, `name`, `profit`, `rent`, `factor`, `overflow`) VALUES
(1, 'scrypt', 0, 0, 1, 1),
(2, 'scryptn', 0, 0, 1, 1),
(3, 'neoscrypt', 0, 0, 1, 1),
(4, 'quark', 0, 0, 1, 1),
(5, 'lyra2', 0, 0, 1, 1),
(6, 'x11', 0, 0, 1, 1),
(7, 'x13', 0, 0, 1, 1),
(8, 'x14', 0, 0, 1, 0),
(9, 'x15', 0, 0, 1, 1),
(10, 'fresh', 0.0026231955438411, 0.0027018914101563, 5, 0),
(11, 'sha256', 0, 0, 1, 1),
(12, 'qubit', 0, 0, 1, 1),
(13, 'skein', 0, 0, 1, 1),
(14, 'groestl', 0, 0, 1, 0),
(15, 'blake', 0, 0, 1, 0),
(16, 'keccak', 0, 0, 1, 0),
(17, 'nist5', 0, 0, 1, 1),
(18, 'zr5', 0, 0, 1, 1),
(19, 'c11', 0, 0, 1, 0),
(20, 'drop', 2.5713261892185e-21, 32.540632674103, 1.5, 0),
(21, 'skein2', 0, 0, 1, 0),
(22, 'bmw', 0.00000000000009119158510914, 0.000072523406145041, 100, 1),
(23, 'argon2', 0, 0, 1, NULL),
(24, 'blake2s', 0, 0, 1, NULL),
(25, 'decred', 0, 0, 1, NULL),
(26, 'luffa', 0, 0, 1, NULL),
(27, 'lyra2v2', 0, 0, 1, NULL),
(28, 'penta', 0, 0, 1, NULL),
(29, 'dmd-gr', 0, 0, 1, NULL),
(30, 'myr-gr', 0, 0, 1, NULL),
(31, 'm7m', 0, 0, 1, NULL),
(32, 'sib', 0, 0, 1, NULL),
(33, 'vanilla', 0, 0, 1, NULL),
(34, 'velvet', 0, 0, 1, NULL),
(35, 'yescrypt', 0, 0, 1, NULL),
(36, 'whirlpool', 0, 0, 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `balances`
--

CREATE TABLE `balances` (
  `id` int(11) NOT NULL,
  `name` varchar(16) DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `onsell` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `balances`
--

INSERT INTO `balances` (`id`, `name`, `balance`, `onsell`) VALUES
(1, 'bittrex', 0, NULL),
(2, 'poloniex', 0, NULL),
(3, 'safecex', 0, NULL),
(4, 'bleutrade', 0, NULL),
(5, 'yobit', 0, NULL),
(6, 'c-cex', 0, NULL),
(7, 'alcurex', 0, NULL),
(8, 'cryptopia', 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `balanceuser`
--

CREATE TABLE `balanceuser` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `pending` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `blocks`
--

CREATE TABLE `blocks` (
  `id` int(11) UNSIGNED NOT NULL,
  `coin_id` int(11) DEFAULT NULL,
  `height` int(11) UNSIGNED DEFAULT NULL,
  `confirmations` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `workerid` int(11) DEFAULT NULL,
  `difficulty_user` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `difficulty` double DEFAULT NULL,
  `category` varchar(16) DEFAULT NULL,
  `algo` varchar(16) DEFAULT 'scrypt',
  `blockhash` varchar(128) DEFAULT NULL,
  `txhash` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Discovered blocks persisted from Litecoin Service';

-- --------------------------------------------------------

--
-- Structure de la table `coins`
--

CREATE TABLE `coins` (
  `id` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `symbol` varchar(16) DEFAULT NULL,
  `symbol2` varchar(16) DEFAULT NULL,
  `algo` varchar(16) DEFAULT NULL,
  `version` varchar(32) DEFAULT NULL,
  `image` varchar(1024) DEFAULT NULL,
  `market` varchar(64) DEFAULT NULL,
  `marketid` int(11) DEFAULT NULL,
  `master_wallet` varchar(1024) DEFAULT NULL,
  `charity_address` varchar(1024) DEFAULT NULL,
  `charity_amount` double DEFAULT NULL,
  `charity_percent` double DEFAULT NULL,
  `deposit_address` varchar(1024) DEFAULT NULL,
  `deposit_minimum` double DEFAULT '1',
  `sellonbid` tinyint(1) DEFAULT NULL,
  `dontsell` tinyint(1) DEFAULT '1',
  `block_explorer` varchar(1024) DEFAULT NULL,
  `index_avg` double DEFAULT NULL,
  `connections` int(11) DEFAULT NULL,
  `errors` varchar(1024) DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `mint` double DEFAULT NULL,
  `txfee` double DEFAULT NULL,
  `payout_min` double DEFAULT NULL,
  `payout_max` double DEFAULT NULL,
  `difficulty` double DEFAULT '1',
  `difficulty_pos` double DEFAULT NULL,
  `block_height` int(11) DEFAULT NULL,
  `target_height` int(11) DEFAULT NULL,
  `network_hash` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `price2` double DEFAULT NULL,
  `reward` double DEFAULT '1',
  `reward_mul` double DEFAULT '1',
  `enable` tinyint(1) DEFAULT '0',
  `auto_ready` tinyint(1) DEFAULT '0',
  `visible` tinyint(1) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `conf_folder` varchar(128) DEFAULT NULL,
  `program` varchar(128) DEFAULT NULL,
  `rpcuser` varchar(128) DEFAULT NULL,
  `rpcpasswd` varchar(128) DEFAULT NULL,
  `serveruser` varchar(45) DEFAULT NULL,
  `rpchost` varchar(128) DEFAULT NULL,
  `rpcport` int(11) DEFAULT NULL,
  `rpccurl` tinyint(1) NOT NULL DEFAULT '0',
  `rpcssl` tinyint(1) NOT NULL DEFAULT '0',
  `rpccert` varchar(255) DEFAULT NULL,
  `rpcencoding` varchar(16) DEFAULT NULL,
  `account` varchar(64) NOT NULL DEFAULT '',
  `hassubmitblock` tinyint(1) DEFAULT NULL,
  `hasmasternodes` tinyint(1) NOT NULL DEFAULT '0',
  `usememorypool` tinyint(1) DEFAULT NULL,
  `txmessage` tinyint(1) DEFAULT NULL,
  `auxpow` tinyint(1) DEFAULT NULL,
  `lastblock` varchar(128) DEFAULT NULL,
  `network_ttf` int(11) DEFAULT NULL,
  `actual_ttf` int(11) DEFAULT NULL,
  `pool_ttf` int(11) DEFAULT NULL,
  `last_network_found` int(11) DEFAULT NULL,
  `installed` tinyint(1) DEFAULT NULL,
  `link_site` varchar(1024) DEFAULT NULL,
  `link_exchange` varchar(1024) DEFAULT NULL,
  `link_bitcointalk` varchar(1024) DEFAULT NULL,
  `link_github` varchar(1024) DEFAULT NULL,
  `link_explorer` varchar(1024) DEFAULT NULL,
  `specifications` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Structure de la table `connections`
--

CREATE TABLE `connections` (
  `id` int(11) NOT NULL,
  `user` varchar(64) DEFAULT NULL,
  `host` varchar(64) DEFAULT NULL,
  `db` varchar(64) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `idle` int(11) DEFAULT NULL,
  `last` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `connections`
--

INSERT INTO `connections` (`id`, `user`, `host`, `db`, `created`, `idle`, `last`) VALUES
(24634, 'root', 'localhost', 'yaamp', 1459693738, 239, 1459693758),
(25098, 'root', 'localhost', 'yaamp', 1459693738, 308, 1459693758),
(25099, 'root', 'localhost', 'yaamp', 1459693738, 301, 1459693758),
(25100, 'root', 'localhost', 'yaamp', 1459693738, 308, 1459693758),
(25101, 'root', 'localhost', 'yaamp', 1459693738, 240, 1459693758),
(25102, 'root', 'localhost', 'yaamp', 1459693738, 300, 1459693758),
(25103, 'root', 'localhost', 'yaamp', 1459693738, 242, 1459693758),
(25104, 'root', 'localhost', 'yaamp', 1459693738, 303, 1459693758),
(25186, 'root', 'localhost', 'yaamp', 1459693738, 10, 1459693738),
(25187, 'root', 'localhost', 'yaamp', 1459693738, 0, 1459693738),
(25189, 'root', 'localhost', 'yaamp', 1459693758, 0, 1459693758);

-- --------------------------------------------------------

--
-- Structure de la table `earnings`
--

CREATE TABLE `earnings` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `coinid` int(11) DEFAULT NULL,
  `blockid` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `mature_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `exchange`
--

CREATE TABLE `exchange` (
  `id` int(11) NOT NULL,
  `coinid` int(11) DEFAULT NULL,
  `send_time` int(11) DEFAULT NULL,
  `receive_time` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `price_estimate` double DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `fee` double DEFAULT NULL,
  `status` varchar(16) DEFAULT NULL,
  `market` varchar(16) DEFAULT NULL,
  `tx` varchar(65) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hashrate`
--

CREATE TABLE `hashrate` (
  `id` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `hashrate` bigint(11) DEFAULT NULL,
  `hashrate_bad` bigint(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `rent` double DEFAULT NULL,
  `earnings` double DEFAULT NULL,
  `difficulty` double DEFAULT NULL,
  `algo` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `hashrate`
--

INSERT INTO `hashrate` (`id`, `time`, `hashrate`, `hashrate_bad`, `price`, `rent`, `earnings`, `difficulty`, `algo`) VALUES
(12574, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'sha256'),
(12575, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'scrypt'),
(12576, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'scryptn'),
(12577, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'argon2'),
(12578, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'blake'),
(12579, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'blake2s'),
(12580, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'decred'),
(12581, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'keccak'),
(12582, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'luffa'),
(12583, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'lyra2'),
(12584, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'lyra2v2'),
(12585, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'neoscrypt'),
(12586, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'nist5'),
(12587, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'penta'),
(12588, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'quark'),
(12589, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'qubit'),
(12590, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'c11'),
(12591, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'x11'),
(12592, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'x13'),
(12593, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'x14'),
(12594, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'x15'),
(12595, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'groestl'),
(12596, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'dmd-gr'),
(12597, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'myr-gr'),
(12598, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'm7m'),
(12599, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'sib'),
(12600, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'skein'),
(12601, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'skein2'),
(12602, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'vanilla'),
(12603, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'velvet'),
(12604, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'yescrypt'),
(12605, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'whirlpool'),
(12606, 1459692900, 0, NULL, 0, 0, NULL, NULL, 'zr5');

-- --------------------------------------------------------

--
-- Structure de la table `hashrenter`
--

CREATE TABLE `hashrenter` (
  `id` int(11) NOT NULL,
  `renterid` int(11) DEFAULT NULL,
  `jobid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `hashrate` double DEFAULT NULL,
  `hashrate_bad` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hashstats`
--

CREATE TABLE `hashstats` (
  `id` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `hashrate` bigint(11) DEFAULT NULL,
  `earnings` double DEFAULT NULL,
  `algo` varchar(16) DEFAULT 'scrypt'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `hashuser`
--

CREATE TABLE `hashuser` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `hashrate` bigint(11) DEFAULT NULL,
  `hashrate_bad` bigint(11) DEFAULT NULL,
  `algo` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `renterid` int(11) DEFAULT NULL,
  `ready` tinyint(1) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `speed` double DEFAULT NULL,
  `difficulty` double DEFAULT NULL,
  `algo` varchar(16) DEFAULT NULL,
  `host` varchar(1024) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(1024) DEFAULT NULL,
  `password` varchar(1024) DEFAULT NULL,
  `percent` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `jobsubmits`
--

CREATE TABLE `jobsubmits` (
  `id` int(11) NOT NULL,
  `jobid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `valid` tinyint(1) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `difficulty` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `algo` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `markets`
--

CREATE TABLE `markets` (
  `id` int(11) NOT NULL,
  `coinid` int(11) DEFAULT NULL,
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `marketid` int(11) DEFAULT NULL,
  `priority` tinyint(1) NOT NULL DEFAULT '0',
  `lastsent` int(11) DEFAULT NULL,
  `lasttraded` int(11) DEFAULT '0',
  `balancetime` int(11) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  `txfee` double DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `ontrade` double NOT NULL DEFAULT '0',
  `price` double DEFAULT NULL,
  `price2` double DEFAULT NULL,
  `pricetime` int(11) DEFAULT NULL,
  `deposit_address` varchar(1024) DEFAULT NULL,
  `message` varchar(2048) DEFAULT NULL,
  `name` varchar(16) DEFAULT NULL,
  `base_coin` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `markets`
--

INSERT INTO `markets` (`id`, `coinid`, `disabled`, `marketid`, `priority`, `lastsent`, `lasttraded`, `balancetime`, `deleted`, `txfee`, `balance`, `ontrade`, `price`, `price2`, `pricetime`, `deposit_address`, `message`, `name`, `base_coin`) VALUES
(1, 155, 0, NULL, 0, NULL, 0, NULL, 0, 0.002, NULL, 0, 0.020691404922548, 0.020814137099131, NULL, NULL, NULL, 'bittrex', NULL),
(3, 142, 0, NULL, 0, 1434521832, 1434524748, NULL, 0, 0.002, NULL, 0, 0.0000048300000002048, 0.0000048499920774144, NULL, NULL, NULL, 'bittrex', NULL),
(8, 153, 0, NULL, 0, NULL, 0, NULL, 0, 0.2, NULL, 0, 0.0000051, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(9, 77, 0, NULL, 0, 1434456939, 1434486428, NULL, 0, 0.02, NULL, 0, 0.000097444125436521, 0.00010256933605979, 1459693553, NULL, NULL, 'bittrex', NULL),
(13, 190, 0, NULL, 0, 1434522685, 1434524748, NULL, 0, 0.02, NULL, 0, 0.00013530436831396, 0.00013841761455646, 1459693554, NULL, NULL, 'bittrex', NULL),
(18, 104, 0, NULL, 0, 1434050553, 1434072251, NULL, 0, 0.2, NULL, 0, 0.000019048800027151, 0.000019239584365976, NULL, NULL, NULL, 'bittrex', NULL),
(19, 196, 0, NULL, 0, NULL, 1427398373, NULL, 0, 0.02, NULL, 0, 0.00000082, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(47, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.020159837398926, 0.02057791933957, NULL, NULL, NULL, 'c-cex', NULL),
(49, 154, 0, NULL, 0, 1415933511, 1415969270, NULL, 0, NULL, NULL, 0, 0.00001247, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(56, 200, 0, NULL, 0, 1420307044, 1421857842, NULL, 0, 0.2, NULL, 0, 0.0000395, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(70, 155, 0, NULL, 0, NULL, 0, NULL, 0, 0.01, NULL, 0, 0.020096017919634, 0.020545593883579, NULL, NULL, NULL, 'bleutrade', NULL),
(84, 104, 0, NULL, 0, 1423481825, 1434072277, NULL, 0, 0.1, NULL, 0, 0.00001852999957504, 0.000019990999864319, NULL, NULL, NULL, 'bleutrade', NULL),
(88, 142, 0, NULL, 0, 1425017779, 1434524781, NULL, 0, 0.1, NULL, 0, 0.0000048, 0.000005030432, NULL, NULL, NULL, 'bleutrade', NULL),
(89, 77, 0, NULL, 0, 1414839892, 1414851008, NULL, 0, 0.001, NULL, 0, 0.000086422036736, 0.0000963320183296, 1459693573, NULL, 'no', 'bleutrade', NULL),
(96, 146, 0, NULL, 0, 1423025840, 1423026664, NULL, 0, 2, NULL, 0, 0.00000070000000020349, 0.00000070500000020414, NULL, NULL, NULL, 'bittrex', NULL),
(98, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000007, 0.0000007050000025559, NULL, NULL, NULL, 'c-cex', NULL),
(99, 146, 0, NULL, 0, NULL, 0, NULL, 0, 2, NULL, 0, 0.00000070000000000164, 0.00000070500160000082, NULL, NULL, NULL, 'bleutrade', NULL),
(102, 200, 0, NULL, 0, 1420309208, 1434524781, NULL, 0, 0.1, NULL, 0, 0.000038, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(125, 299, 0, NULL, 0, 1436271690, 1436272114, NULL, 0, 0.1, NULL, 0, 0.00000066806709756068, 0.00000076903354878034, 1459693560, NULL, NULL, 'bleutrade', NULL),
(134, 190, 0, NULL, 0, 1425510082, 1426033220, NULL, 0, 0.1, NULL, 0, 0.00011001, 0.00014000499999998, 1459693572, NULL, NULL, 'bleutrade', NULL),
(142, 326, 0, NULL, 0, 1431863219, 1434524778, NULL, 0, 0.1, NULL, 0, 0.000000119999355904, 0.000000144999919616, NULL, NULL, NULL, 'bleutrade', NULL),
(143, 245, 0, NULL, 0, 1431591448, 1431863719, NULL, 0, 0.1, NULL, 0, 0.00000021, 0.000000225, NULL, NULL, NULL, 'bleutrade', NULL),
(154, 346, 0, NULL, 0, 1434277674, 1436167349, NULL, 0, 0.02, NULL, 0, 0.00015345354342399, 0.00015409975991235, 1459693551, NULL, NULL, 'bittrex', NULL),
(167, 308, 0, NULL, 0, NULL, 1434503381, NULL, 0, 0.2, NULL, 0, 0.000021680013080431, 0.000021721607269244, 1459693551, NULL, NULL, 'bittrex', NULL),
(178, 374, 0, NULL, 0, 1423507748, 1423599532, NULL, 0, 0.002, NULL, 0, 0.000040189290869924, 0.000041081167418411, NULL, NULL, NULL, 'bittrex', NULL),
(188, 386, 0, NULL, 0, 1422010095, 1434524748, NULL, 0, 0.002, NULL, 0, 0.00000104, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(191, 392, 0, NULL, 0, 1421173018, 1432385898, NULL, 0, 0.2, NULL, 0, 0.000018520784, 0.000019333716782215, NULL, NULL, NULL, 'bittrex', NULL),
(193, 392, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.00001891, 0.000018955, NULL, NULL, NULL, 'bleutrade', NULL),
(194, 393, 0, NULL, 0, 1434510421, 1434524747, NULL, 0, 0.2, NULL, 0, 0.0006311526144897, 0.00063211368646088, NULL, NULL, NULL, 'bittrex', NULL),
(195, 393, 0, NULL, 0, 1420517421, 1420736934, NULL, 0, 0.1, NULL, 0, 0.00060510991679263, 0.00063295728637071, NULL, NULL, NULL, 'bleutrade', NULL),
(197, 394, 0, NULL, 0, 1424559716, 1434524780, NULL, 0, 0.1, NULL, 0, 0.00013842904806402, 0.00015533020883201, NULL, NULL, NULL, 'bleutrade', NULL),
(198, 390, 0, NULL, 0, 1423640237, 1429477846, NULL, 0, 2, NULL, 0, 0.00000109, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(205, 399, 0, NULL, 0, NULL, 0, NULL, 0, 0.001, NULL, 0, 0.000044806695628034, 0.000049184349414017, NULL, NULL, NULL, 'bleutrade', NULL),
(215, 406, 0, NULL, 0, 1434397280, 1434400798, NULL, 0, 0.2, NULL, 0, 0.0000011300026943485, 0.0000011358029507753, 1459693554, NULL, NULL, 'bittrex', NULL),
(224, 418, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(225, 419, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(227, 421, 0, NULL, 0, NULL, 1434524748, NULL, 0, 0.2, NULL, 0, 0.00000026000012799476, 0.00000026503212801442, NULL, NULL, NULL, 'bittrex', NULL),
(228, 422, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(230, 424, 0, NULL, 0, NULL, 1434524746, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(232, 404, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(233, 426, 0, NULL, 0, NULL, 0, NULL, 0, 0.2, NULL, 0, 0.00001542, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(236, 428, 0, NULL, 0, 1434524344, 1434523108, NULL, 0, 0.2, NULL, 0, 0.0000034096001026077, 0.0000034547618453504, NULL, NULL, NULL, 'bittrex', NULL),
(237, 429, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(240, 432, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(242, 434, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(243, 435, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(244, 436, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(245, 437, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(246, 438, 0, NULL, 0, NULL, 1436109965, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(247, 439, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(248, 440, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(249, 441, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(251, 443, 0, NULL, 0, NULL, 0, NULL, 0, 0.2, NULL, 0, 0.00000965, 0.0000098, NULL, NULL, NULL, 'bittrex', NULL),
(252, 444, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(253, 445, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(254, 446, 0, NULL, 0, NULL, 0, NULL, 0, 0.02, NULL, 0, 0.00012347, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(259, 450, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(260, 451, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(261, 452, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(262, 453, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(266, 457, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(267, 458, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(270, 349, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(271, 461, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(273, 463, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(277, 467, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(279, 469, 0, NULL, 0, 1431862294, 1431865557, NULL, 0, 0.02, NULL, 0, 0.00001470802227712, 0.0000151630624256, NULL, NULL, NULL, 'bittrex', NULL),
(282, 472, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(285, 475, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(286, 476, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(287, 477, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(289, 479, 0, NULL, 0, NULL, 0, NULL, 0, 0.02, NULL, 0, 0.00374449, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(292, 482, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(295, 485, 0, NULL, 0, 1434041257, 1434054876, NULL, 0, 0.0002, NULL, 0, 0.0095050259002821, 0.009752507950141, NULL, NULL, NULL, 'bittrex', NULL),
(297, 487, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(298, 488, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(299, 489, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(301, 491, 0, NULL, 0, NULL, 0, NULL, 0, 0.2, NULL, 0, 0.000017950012800033, 0.000018415006400016, NULL, NULL, '', 'bittrex', NULL),
(302, 492, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(304, 494, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(306, 496, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(308, 498, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(309, 499, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(312, 502, 0, NULL, 0, 1434492181, 1434523106, NULL, 0, 0.2, NULL, 0, 0.000034526577749221, 0.000035339968871901, 1459693554, NULL, NULL, 'bittrex', NULL),
(314, 504, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(317, 371, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(318, 507, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(321, 192, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(324, 512, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(327, 515, 0, NULL, 0, NULL, 1434523112, NULL, 0, 0.2, NULL, 0, 0.000001476, 0.000001543, NULL, NULL, NULL, 'bittrex', NULL),
(328, 516, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(331, 519, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(333, 521, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(409, 553, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(412, 479, 0, NULL, 0, NULL, 0, NULL, 0, 0.001, NULL, 0, 0.00115, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(413, 336, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(415, 555, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(416, 556, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(417, 557, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(421, 560, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(424, 561, 0, NULL, 0, 1425479934, 1425523859, NULL, 0, 0.1, NULL, 0, 0.00000006, 0.0000000650064, NULL, NULL, NULL, 'bleutrade', NULL),
(425, 562, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(426, 424, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(427, 563, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(430, 565, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(431, 566, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(432, 567, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(433, 568, 0, NULL, 0, 1431862299, 1431863723, NULL, 0, 0.1, NULL, 0, 0.0000117899999744, 0.0000126350015872, NULL, NULL, NULL, 'bleutrade', NULL),
(434, 569, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(437, 572, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(442, 491, 0, NULL, 0, NULL, 0, NULL, 0, 0.001, NULL, 0, 0.00001624, 0.000025095, NULL, NULL, NULL, 'bleutrade', NULL),
(443, 574, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(444, 575, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(446, 502, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.000022010000185635, 0.000032540000092816, 1459693561, NULL, NULL, 'bleutrade', NULL),
(447, 428, 0, NULL, 0, 1433038808, 1433069058, NULL, 0, 0.1, NULL, 0, 0.0000033553829120072, 0.0000034626914560036, NULL, NULL, NULL, 'bleutrade', NULL),
(448, 577, 0, NULL, 0, NULL, 0, NULL, 0, 0.015, NULL, 0, 0.00147, 0.00148, NULL, NULL, NULL, 'bleutrade', NULL),
(449, 578, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(450, 579, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.000037, 0.00003736, NULL, NULL, NULL, 'bleutrade', NULL),
(451, 580, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(455, 530, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(457, 585, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.0013300408, 0.001342805968, NULL, NULL, NULL, 'bleutrade', NULL),
(458, 305, 0, NULL, 0, 1432864372, 1434524781, NULL, 0, 0.001, NULL, 0, 0.00000921992, 0.000010089959999994, 1459693562, NULL, NULL, 'bleutrade', NULL),
(460, 418, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(461, 426, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.00001399, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(462, 257, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(466, 485, 0, NULL, 0, NULL, 1434067528, NULL, 0, 0.01, NULL, 0, 0.0090009451574423, 0.0095004675787211, NULL, NULL, NULL, 'bleutrade', NULL),
(469, 440, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(470, 590, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(473, 251, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(474, 591, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(484, 594, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000116, 0.0000013750000001108, NULL, NULL, NULL, 'c-cex', NULL),
(485, 512, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(491, 557, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(492, 274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(496, 561, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000005, 0.000000055000000004096, NULL, NULL, NULL, 'c-cex', NULL),
(515, 313, 0, NULL, 0, NULL, 1436040221, NULL, 0, NULL, NULL, 0, 0.00000925, 0.00000955, NULL, NULL, NULL, 'c-cex', NULL),
(526, 419, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(540, 397, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(542, 408, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(543, 612, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00001072, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(548, 333, 0, NULL, 0, NULL, 1420029280, NULL, 0, NULL, NULL, 0, 0.00000097, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(558, 344, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(770, 522, 0, NULL, 0, NULL, 1434524749, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(771, 523, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(773, 524, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(782, 257, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(783, 260, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(789, 265, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(792, 532, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(797, 306, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(798, 247, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(799, 533, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(812, 320, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(813, 327, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(814, 330, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(815, 363, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(816, 335, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(819, 338, 0, NULL, 0, NULL, 1434524749, NULL, 0, 0.2, NULL, 0, 0.00000006, 0.000000065, 1459693554, NULL, NULL, 'bittrex', NULL),
(824, 251, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(830, 361, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(833, 364, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(837, 301, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(839, 295, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(842, 382, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(845, 387, 0, NULL, 0, 1420824179, 1420898418, NULL, 0, 0.2, NULL, 0, 0.00000007, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(849, 385, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(850, 412, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(851, 409, 0, NULL, 0, NULL, 0, NULL, 0, 0.002, NULL, 0, 0.00224601, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(852, 415, 0, NULL, 0, NULL, 1436109967, NULL, 0, 0.002, NULL, 0, 0.000019687996799795, 0.000022273999167898, 1459693555, NULL, NULL, 'bittrex', NULL),
(853, 416, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(857, 268, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(860, 596, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(861, 752, 0, NULL, 0, 1426219841, 1426401291, NULL, 0, 0.2, NULL, 0, 0.00000005, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(862, 753, 0, NULL, 0, 1431737811, 1434524746, NULL, 0, 0.2, NULL, 0, 0, 0.0000017150000061396, NULL, NULL, 'Wallet to be removed on 6/5.  Please withdraw all funds immediately.', 'bittrex', NULL),
(868, 757, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(871, 413, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(875, 760, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(877, 760, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(878, 761, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(882, 765, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000003, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(885, 768, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(886, 767, 0, NULL, 0, NULL, 1421263146, NULL, 0, 0.2, NULL, 0, 0.00005313, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(887, 769, 0, NULL, 0, 1421419096, 1421420072, NULL, 0, 0.2, NULL, 0, 0.00009004, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(892, 686, 0, NULL, 0, 1434414916, 1434500156, NULL, 0, 0.2, NULL, 0, 0.00000060000000512, 0.00000060500000512001, NULL, NULL, NULL, 'bittrex', NULL),
(896, 775, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(897, 776, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(898, 777, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(900, 778, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00029001, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(901, 327, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000031, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(903, 780, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000029, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(905, 450, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00009326, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(906, 781, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000009, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(907, 782, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000026, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(909, 760, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00006821, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(910, 320, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00009976, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(912, 398, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00008187, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(913, 371, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00002025, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(914, 512, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000155, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(915, 783, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000151, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(917, 784, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00002321, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(920, 413, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00663315, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(921, 786, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00017972, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(923, 441, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.000031, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(925, 789, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(926, 146, 0, NULL, 0, NULL, 1423352890, NULL, 0, NULL, NULL, 0, 0.00000070000000512, 0.00000070500000512, NULL, NULL, NULL, 'poloniex', NULL),
(928, 790, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(929, 596, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000054, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(931, 507, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00066038, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(932, 791, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000048, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(933, 660, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000083, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(935, 792, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000206, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(937, 794, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00005403, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(942, 796, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.000001209199993856, 0.000001279599995392, NULL, NULL, NULL, 'poloniex', NULL),
(945, 312, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000133, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(946, 798, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000115, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(949, 800, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000058, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(950, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.02049031911929, 0.020613860350444, NULL, NULL, NULL, 'poloniex', NULL),
(951, 801, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00008689, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(952, 802, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000082, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(953, 803, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00001743, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(954, 574, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000005, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(955, 804, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000477, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(956, 805, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.000049, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(959, 807, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000083, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(961, 421, 0, NULL, 0, 1428642406, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000026000000491684, 0.00000027000000245514, NULL, NULL, NULL, 'poloniex', NULL),
(962, 439, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00004799, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(963, 475, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00002104, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(964, 808, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.0041996, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(965, 502, 0, NULL, 0, 1432803047, 1436109223, NULL, 0, NULL, NULL, 0, 0.000035594989146357, 0.000035667423056367, 1459693556, NULL, NULL, 'poloniex', NULL),
(966, 577, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00142, 0.001435, NULL, NULL, NULL, 'poloniex', NULL),
(967, 431, 0, NULL, 0, 1425472701, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000008, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(968, 154, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00004531, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(969, 809, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00017201, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(973, 811, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000009, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(974, 487, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000036, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(975, 142, 0, NULL, 0, 1428641263, 1436109223, NULL, 0, NULL, NULL, 0, 0.000004739984256, 0.000004774992192, NULL, NULL, NULL, 'poloniex', NULL),
(976, 585, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.0013156711733939, 0.0013469972641435, NULL, NULL, NULL, 'poloniex', NULL),
(979, 314, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00012501, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(980, 469, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.000015580736714752, 0.000015914622434849, NULL, NULL, NULL, 'poloniex', NULL),
(981, 153, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00001298, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(982, 418, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000005, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(983, 813, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.0000124, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(985, 704, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000064, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(986, 814, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00006407, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(991, 817, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00004681, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(992, 442, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.3122371, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(993, 390, 0, NULL, 0, 1423703964, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000163, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(997, 818, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.010802, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(999, 374, 0, NULL, 0, 1422778258, 1423598296, NULL, 0, NULL, NULL, 0, 0.000040150000429505, 0.000042421748986446, NULL, NULL, NULL, 'poloniex', NULL),
(1001, 346, 0, NULL, 0, 1428336986, 1436210848, NULL, 0, NULL, NULL, 0, 0.0001523173038348, 0.00015290313884901, 1459693556, NULL, NULL, 'poloniex', NULL),
(1002, 399, 0, NULL, 0, 1428322427, 1436109223, NULL, 0, NULL, NULL, 0, 0.000047434337794536, 0.000048237169242868, NULL, NULL, NULL, 'poloniex', NULL),
(1005, 821, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00117501, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1006, 445, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00009802, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1007, 822, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000086, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1008, 823, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000069, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1009, 824, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00430013, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1011, 463, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000031, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1013, 251, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00009012, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1014, 457, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00339875, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1015, 591, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00008556, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1016, 268, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00003583, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1017, 476, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00001556, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1018, 826, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00390001, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1019, 827, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00000001, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1023, 830, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1030, 837, 0, NULL, 0, NULL, 1436109224, NULL, 0, NULL, NULL, 0, 0.00000251, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1031, 838, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1033, 839, 0, NULL, 0, 1422894873, 1422895044, NULL, 0, 0.02, NULL, 0, 0.00000815, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1036, 798, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1040, 844, 0, NULL, 0, 1434510428, 1434518266, NULL, 0, NULL, NULL, 0, 0.0000365, 0.00003823, 1459693578, NULL, NULL, 'c-cex', NULL),
(1041, 845, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00795404, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1044, 406, 0, NULL, 0, 1428611245, 1436109223, NULL, 0, NULL, NULL, 0, 0.0000011296033115687, 0.0000011346033238733, 1459693556, NULL, NULL, 'poloniex', NULL),
(1046, 847, 0, NULL, 0, 1424831798, 1424833376, NULL, 0, 0.2, NULL, 0, 0.000002, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1048, 824, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1050, 607, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1051, 814, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1056, 854, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1058, 856, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1059, 768, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1061, 857, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000001, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1078, 846, 0, NULL, 0, 1428667309, 1436109223, NULL, 0, NULL, NULL, 0, 0.00011612855736746, 0.00011870760483286, 1459693556, NULL, NULL, 'poloniex', NULL),
(1080, 601, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1082, 561, 0, NULL, 0, 1433930064, 1433931225, NULL, 0, 0.2, NULL, 0, 0.00000005, 0.000000055, NULL, NULL, NULL, 'bittrex', NULL),
(1083, 846, 0, NULL, 0, NULL, 1434524746, NULL, 0, 0.002, NULL, 0, 0.00011234863136481, 0.0001204193156824, 1459693555, NULL, NULL, 'bittrex', NULL),
(1088, 869, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00001303, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1090, 791, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1097, 868, 0, NULL, 0, NULL, 1424963698, NULL, 0, 0.2, NULL, 0, 0.00000894, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1098, 873, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1099, 794, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1102, 601, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1108, 878, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1110, 877, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.0000059999999999459, 0.000006994999999973, 1459693576, NULL, NULL, 'bleutrade', NULL),
(1111, 876, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1115, 871, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1117, 880, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1119, 417, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1121, 364, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1122, 417, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, 0.00000353, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1123, 881, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1125, 883, 0, NULL, 0, 1426643038, 1434524746, NULL, 0, 0.2, NULL, 0, 0.0000026, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1126, 884, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1131, 885, 0, NULL, 0, NULL, 0, NULL, 0, 2, NULL, 0, 0.00000005, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1132, 887, 0, NULL, 0, 1434524349, 1434515781, NULL, 0, 0.2, NULL, 0, 0.0000090099968, 0.0000099198192002151, NULL, NULL, NULL, 'bittrex', NULL),
(1140, 893, 0, NULL, 0, NULL, 0, NULL, 0, 0.03, NULL, 0, 0.016246585601019, 0.01629695159333, 1459693558, NULL, NULL, 'bleutrade', NULL),
(1142, 890, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1143, 894, 0, NULL, 0, NULL, 0, NULL, 0, 2, NULL, 0, 0.00000002, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1144, 893, 0, NULL, 0, 1428665177, 1436109223, NULL, 0, NULL, NULL, 0, 0.01622779408702, 0.016287180443826, 1459693556, NULL, NULL, 'poloniex', NULL),
(1145, 893, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.011229984576, 0.01311578732, NULL, NULL, NULL, 'c-cex', NULL),
(1148, 893, 0, NULL, 0, 1434802685, 1436109965, NULL, 0, 0.002, NULL, 0, 0.016167211405921, 0.016272272820699, 1459693552, NULL, NULL, 'bittrex', NULL),
(1149, 865, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000001, 0.000005, NULL, NULL, NULL, 'c-cex', NULL),
(1156, 903, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1158, 333, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1164, 808, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1165, 898, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1167, 910, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000417, 0.00000558, NULL, NULL, NULL, 'c-cex', NULL),
(1172, 874, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1174, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.02, 0.029450080000041, NULL, NULL, NULL, 'yobit', NULL),
(1175, 577, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00002101, 0.001060505, NULL, NULL, NULL, 'yobit', NULL),
(1176, 585, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0008, 0.00105, NULL, NULL, NULL, 'yobit', NULL),
(1177, 893, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.01080004992, 0.01276997496, NULL, NULL, NULL, 'yobit', NULL),
(1178, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000069, 0.00000070003999999997, NULL, NULL, NULL, 'yobit', NULL),
(1180, 104, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00001603, 0.000020465, NULL, NULL, NULL, 'yobit', NULL),
(1181, 77, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000001, 0.044940005, NULL, NULL, NULL, 'yobit', NULL),
(1182, 523, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1183, 374, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000001, 0.000050005, NULL, NULL, NULL, 'yobit', NULL),
(1184, 489, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1185, 190, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0002222132096, 0.0004411258048, NULL, NULL, NULL, 'yobit', NULL),
(1186, 354, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1187, 346, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000001, 0.025000005, NULL, NULL, NULL, 'yobit', NULL),
(1188, 306, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1191, 466, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1192, 409, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1193, 897, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1194, 914, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1195, 915, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1196, 881, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1197, 908, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1198, 916, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1199, 894, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000004, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1200, 917, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1201, 918, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1202, 919, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000125, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1203, 885, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1204, 920, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1205, 921, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1206, 922, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1207, 923, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1208, 493, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1209, 868, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1210, 867, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1211, 875, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1212, 854, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1213, 876, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1215, 889, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1216, 852, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1217, 924, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1218, 891, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1219, 899, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1220, 387, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1221, 413, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1222, 925, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1223, 907, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1224, 911, 0, NULL, 0, 1429824397, 1434524792, NULL, 0, NULL, NULL, 0, 0.00000001, 0.00000008, NULL, NULL, NULL, 'yobit', NULL),
(1225, 926, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1226, 154, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1227, 418, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1228, 910, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000361, 0.00000443, NULL, NULL, NULL, 'yobit', NULL),
(1229, 333, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1231, 892, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000006, 0.00000021, NULL, NULL, NULL, 'yobit', NULL),
(1232, 927, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1233, 928, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1234, 890, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1235, 895, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1236, 896, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1237, 929, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1238, 930, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1239, 906, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1240, 931, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1241, 932, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1242, 606, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1244, 385, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1245, 383, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1246, 764, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1247, 933, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1248, 765, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1250, 767, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1251, 433, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1252, 747, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1253, 772, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1254, 410, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1255, 475, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1256, 416, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1257, 766, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1258, 771, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1259, 390, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1260, 713, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1261, 759, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1262, 530, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1263, 762, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1264, 934, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1265, 935, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1266, 756, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1267, 844, 0, NULL, 0, 1431437814, 1431543768, NULL, 0, NULL, NULL, 0, 0.00012399999999995, 0.00014099999999997, NULL, NULL, NULL, 'yobit', NULL),
(1268, 846, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000501, 0.000502505, NULL, NULL, NULL, 'yobit', NULL),
(1269, 406, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000007, 0.00000022, NULL, NULL, NULL, 'yobit', NULL),
(1270, 847, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1271, 723, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1272, 453, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1273, 849, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1274, 187, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1275, 936, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1276, 561, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000005, 0.00000006, NULL, NULL, NULL, 'yobit', NULL),
(1277, 855, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1278, 905, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1279, 382, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1280, 769, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1281, 361, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1282, 937, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1283, 831, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1284, 938, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1285, 516, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1286, 828, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1288, 835, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1289, 857, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1290, 939, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1291, 940, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00035, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1293, 941, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1294, 942, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00001152, 0.000019760000002228, NULL, NULL, NULL, 'yobit', NULL),
(1299, 940, 0, NULL, 0, 1428985738, 1428986353, NULL, 0, 0.02, NULL, 0, 0.00043, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1302, 913, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1303, 944, 0, NULL, 0, 1431863233, 1434524790, NULL, 0, NULL, NULL, 0, 0.00000003, 0.000000037, NULL, NULL, NULL, 'yobit', NULL),
(1305, 479, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1307, 945, 0, NULL, 0, 1431022850, 1431865590, NULL, 0, NULL, NULL, 0, 0.00000004, 0.000000385, NULL, NULL, NULL, 'yobit', NULL),
(1308, 260, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1313, 946, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000102, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1320, 948, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00150002, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1321, 950, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000003000000768, 0.000006435000384, NULL, NULL, NULL, 'c-cex', NULL),
(1322, 951, 0, NULL, 0, 1431791086, 1431865591, NULL, 0, NULL, NULL, 0, 0.000375, 0.000587495, NULL, NULL, NULL, 'yobit', NULL),
(1323, 948, 0, NULL, 0, NULL, 1429408966, NULL, 0, 0.002, NULL, 0, 0.0025348, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1324, 413, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL);
INSERT INTO `markets` (`id`, `coinid`, `disabled`, `marketid`, `priority`, `lastsent`, `lasttraded`, `balancetime`, `deleted`, `txfee`, `balance`, `ontrade`, `price`, `price2`, `pricetime`, `deposit_address`, `message`, `name`, `base_coin`) VALUES
(1325, 952, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1326, 953, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1329, 955, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000806, 0.00010280367994982, NULL, NULL, NULL, 'yobit', NULL),
(1330, 956, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1335, 952, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1336, 955, 0, NULL, 0, 1429590816, 1429591388, NULL, 0, 0.02, NULL, 0, 0.000073249441894186, 0.000076650649519521, NULL, NULL, NULL, 'bittrex', NULL),
(1342, 957, 0, NULL, 0, NULL, 0, NULL, 0, 0.002, NULL, 0, 0.000749168, 0.000792856, NULL, NULL, NULL, 'bittrex', NULL),
(1344, 959, 0, NULL, 0, NULL, 0, NULL, 0, 0.2, NULL, 0, 0.00000031999987691521, 0.00000033000012011524, 1459693553, NULL, NULL, 'bittrex', NULL),
(1346, 959, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000032999997747043, 0.00000033500125747056, 1459693556, NULL, NULL, 'poloniex', NULL),
(1355, 963, 0, NULL, 0, 1429738252, 1429764366, NULL, 0, NULL, NULL, 0, 0.00000356, 0.000026769999999999, NULL, NULL, NULL, 'yobit', NULL),
(1356, 964, 0, NULL, 0, 1430523537, 1430525338, NULL, 0, NULL, NULL, 0, 0.00000449, 0.000006245, NULL, NULL, NULL, 'yobit', NULL),
(1363, 949, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1364, 965, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1365, 967, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1366, 968, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1367, 969, 0, NULL, 0, 1431862329, 1431865593, NULL, 0, NULL, NULL, 0, 0.00000001, 0.000000015, NULL, NULL, NULL, 'yobit', NULL),
(1368, 970, 0, NULL, 0, 1430009999, 1434524790, NULL, 0, NULL, NULL, 0, 0.00007004, 0.000094539991971185, NULL, NULL, NULL, 'yobit', NULL),
(1370, 886, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1373, 489, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1378, 947, 0, NULL, 0, NULL, 1434523102, NULL, 0, 0.2, NULL, 0, 0.000030087398506694, 0.000032915158984526, NULL, NULL, NULL, 'bittrex', NULL),
(1382, 974, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1385, 976, 0, NULL, 0, 1430172183, 1430195149, NULL, 0, NULL, NULL, 0, 0.00001204, 0.000017019600332512, NULL, NULL, NULL, 'yobit', NULL),
(1391, 978, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1392, 979, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000047039577440256, 0.000050000827872484, NULL, NULL, NULL, 'c-cex', NULL),
(1393, 980, 0, NULL, 0, 1431862329, 1431864637, NULL, 0, NULL, NULL, 0, 0.00000002, 0.000000025, NULL, NULL, NULL, 'yobit', NULL),
(1394, 710, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1397, 981, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1401, 982, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00005601, 0.000083010008512826, NULL, NULL, NULL, 'yobit', NULL),
(1402, 983, 0, NULL, 0, NULL, 1430399777, NULL, 0, NULL, NULL, 0, 0.00000075, 0.0000011251999913779, NULL, NULL, NULL, 'yobit', NULL),
(1406, 985, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000031, 0.0000058253568, NULL, NULL, NULL, 'yobit', NULL),
(1407, 986, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1408, 651, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1409, 987, 0, NULL, 0, 1431118034, 1434524790, NULL, 0, NULL, NULL, 0, 0.00000094, 0.00000522, NULL, NULL, NULL, 'yobit', NULL),
(1410, 988, 0, NULL, 0, 1430606422, 1430608238, NULL, 0, NULL, NULL, 0, 0.00002275, 0.000025757345030349, NULL, NULL, NULL, 'yobit', NULL),
(1413, 964, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000004, 0.0000065, NULL, NULL, NULL, 'c-cex', NULL),
(1414, 990, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1460, 988, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1462, 992, 0, NULL, 0, 1431863234, 1431864747, NULL, 0, NULL, NULL, 0, 0.00000051, 0.0000007500064, NULL, NULL, NULL, 'c-cex', NULL),
(1476, 990, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1478, 994, 0, NULL, 0, 1431146575, 1434524790, NULL, 0, NULL, NULL, 0, 0.00015005, 0.000275025, NULL, NULL, NULL, 'yobit', NULL),
(1479, 995, 0, NULL, 0, NULL, 1430851096, NULL, 0, NULL, NULL, 0, 0.00002708, 0.000028340605508011, NULL, NULL, NULL, 'yobit', NULL),
(1481, 996, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000009, 0.000000365, NULL, NULL, NULL, 'yobit', NULL),
(1482, 997, 0, NULL, 0, 1430893619, 1430894261, NULL, 0, NULL, NULL, 0, 0.00007, 0.000083897050548957, NULL, NULL, NULL, 'yobit', NULL),
(1484, 999, 0, NULL, 0, 1431862331, 1434524790, NULL, 0, NULL, NULL, 0, 0.00000081, 0.0000012000000000002, NULL, NULL, NULL, 'yobit', NULL),
(1485, 1000, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1487, 999, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000008, 0.000001595, NULL, NULL, NULL, 'c-cex', NULL),
(1492, 1001, 0, NULL, 0, 1431794102, 1431865593, NULL, 0, NULL, NULL, 0, 0.00001501, 0.00001551, NULL, NULL, NULL, 'yobit', NULL),
(1494, 1003, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000055, 0.00000066995712, NULL, NULL, NULL, 'yobit', NULL),
(1497, 1006, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1503, 1010, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1504, 987, 0, NULL, 0, 1434523509, 1434524750, NULL, 0, 2, NULL, 0, 0.0000046390871703106, 0.0000056951034645045, NULL, NULL, NULL, 'bittrex', NULL),
(1507, 1011, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1508, 898, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1510, 1012, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1511, 1013, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1512, 606, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1515, 1015, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1516, 1016, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1517, 1017, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1518, 1018, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000004, 0.00000132, NULL, NULL, NULL, 'yobit', NULL),
(1520, 1020, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1522, 1021, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1525, 1010, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1528, 1020, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1529, 486, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1530, 1023, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1532, 1024, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00015, 0.000247495, NULL, NULL, NULL, 'yobit', NULL),
(1534, 1026, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000215, 0.00002155, NULL, NULL, NULL, 'yobit', NULL),
(1536, 1019, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1538, 998, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1539, 1015, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1540, 984, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1541, 1026, 0, NULL, 0, NULL, 0, NULL, 0, 0.02, NULL, 0, 0.00001031919999873, 0.000012074606847447, NULL, NULL, NULL, 'bittrex', NULL),
(1542, 1026, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.00001305, 0.00002414752672, NULL, NULL, NULL, 'bleutrade', NULL),
(1547, 859, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1563, 432, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1564, 1037, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1565, 1030, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000601, 0.00001115008188177, NULL, NULL, NULL, 'yobit', NULL),
(1566, 1029, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1567, 1034, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1568, 1038, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1569, 1039, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1570, 1032, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000002, 0.0000032942000021914, NULL, NULL, NULL, 'yobit', NULL),
(1571, 1040, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000015, 0.0000010750544, NULL, NULL, NULL, 'yobit', NULL),
(1572, 1041, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1573, 1033, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1581, 571, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1582, 1043, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1583, 1031, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1588, 1044, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1589, 844, 0, NULL, 0, NULL, 1434475894, NULL, 0, 0.1, NULL, 0, 0.00003712799936, 0.00004355899968, 1459693557, NULL, NULL, 'bleutrade', NULL),
(1590, 854, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1591, 570, 0, NULL, 0, NULL, 1434524778, NULL, 0, 0.1, NULL, 0, 0, 0.000000005, 1459693559, NULL, NULL, 'bleutrade', NULL),
(1595, 346, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.00013813110079877, 0.00014781055167939, 1459693574, NULL, NULL, 'bleutrade', NULL),
(1596, 1046, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1598, 440, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1599, 1048, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1601, 1050, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1602, 1047, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1606, 1052, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1607, 1053, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1608, 1054, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1610, 1055, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1611, 516, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1612, 1056, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1613, 949, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1614, 1046, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1616, 1057, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1617, 299, 1, NULL, 0, 1436220598, 1436296102, NULL, 0, 0.2, NULL, 0, 0, 0.0000003, NULL, NULL, 'Wallet maintanence', 'bittrex', NULL),
(1618, 1047, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1619, 1001, 0, NULL, 0, NULL, 0, NULL, 0, 0.02, NULL, 0, 0.0000131591936, 0.000014790172232729, NULL, NULL, NULL, 'bittrex', NULL),
(1620, 1058, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1621, 247, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1622, 1059, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1623, 1060, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1624, 1061, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1625, 1062, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1626, 1063, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1627, 1064, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1628, 1065, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1629, 753, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1633, 1068, 0, NULL, 0, 1433781998, 1433782550, NULL, 0, NULL, NULL, 0, 0.00000986, 0.000011410026560414, NULL, NULL, NULL, 'yobit', NULL),
(1634, 1069, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1635, 419, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1636, 1070, 0, NULL, 0, 1433884061, 1433888487, NULL, 0, NULL, NULL, 0, 0.00000007, 0.0000000952, NULL, NULL, NULL, 'yobit', NULL),
(1637, 1071, 0, NULL, 0, 1433877405, 1433883675, NULL, 0, NULL, NULL, 0, 0.00001002, 0.00001974, NULL, NULL, NULL, 'yobit', NULL),
(1638, 1072, 0, NULL, 0, NULL, 1434524792, NULL, 0, NULL, NULL, 0, 0.00000002, 0.000000074999999993446, NULL, NULL, NULL, 'yobit', NULL),
(1642, 1068, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.0000080199999997952, 0.00001396000001321, NULL, NULL, NULL, 'bleutrade', NULL),
(1650, 1071, 0, NULL, 0, 1434516929, 1434523099, NULL, 0, 0.002, NULL, 0, 0.000030971599942451, 0.000037941389558406, NULL, NULL, NULL, 'bittrex', NULL),
(1653, 1074, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1656, 1076, 0, NULL, 0, NULL, 0, NULL, NULL, NULL, NULL, 0, 3.3915, 3.585, NULL, NULL, NULL, 'jubi', NULL),
(1657, 1077, 0, NULL, 0, NULL, 1434524790, NULL, 0, NULL, NULL, 0, 0.00000015, 0.00000029, NULL, NULL, NULL, 'yobit', NULL),
(1658, 1069, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1661, 874, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1662, 1080, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1663, 1081, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000488, 0.00010244, NULL, NULL, NULL, 'yobit', NULL),
(1667, 1079, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000027, 0.00000051000000000082, NULL, NULL, NULL, 'yobit', NULL),
(1668, 1084, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1669, 1085, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1672, 563, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1673, 1087, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1674, 1088, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000004, 0.00000005, NULL, NULL, NULL, 'yobit', NULL),
(1675, 1089, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1676, 1090, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1677, 1064, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1678, 713, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1679, 1091, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1680, 1083, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1681, 1083, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1682, 1090, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1683, 1092, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1690, 1098, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1691, 488, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1692, 719, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1693, 1093, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1694, 1099, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1695, 1100, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1696, 1101, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1697, 1102, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1698, 1103, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1699, 1104, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1700, 1105, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1701, 1106, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1702, 1107, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1703, 1108, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1704, 1109, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1705, 1110, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1706, 1111, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1707, 1112, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1708, 1092, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1709, 1113, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1710, 1097, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1711, 616, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1712, 1114, 0, 2082, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000013327999999985, 0.0000021799999999992, NULL, NULL, NULL, 'cryptopia', NULL),
(1716, 1096, 0, NULL, 0, NULL, 1436109223, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(1776, 1181, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1777, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.018424979999502, 0.019280498361752, NULL, NULL, NULL, 'cryptopia', NULL),
(1778, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000006762784, 0.00000070004, NULL, NULL, NULL, 'cryptopia', NULL),
(1779, 347, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000000588, 0.0000003, NULL, NULL, NULL, 'cryptopia', NULL),
(1780, 142, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000049293999999999, 0.000005415, NULL, NULL, NULL, 'cryptopia', NULL),
(1782, 1182, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1784, 418, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1785, 1184, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1787, 406, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000021559987496006, 0.00000023499993620454, NULL, NULL, NULL, 'cryptopia', NULL),
(1789, 770, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1790, 391, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1791, 299, 0, NULL, 0, NULL, 0, NULL, 0, 0.1, NULL, 0, 0.0000002156, 0.000000505, NULL, NULL, NULL, 'cryptopia', NULL),
(1792, 1185, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1793, 1186, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1796, 587, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1797, 771, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1798, 251, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1799, 743, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1801, 765, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1803, 1188, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1804, 469, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1805, 1189, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1806, 1190, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1808, 949, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1810, 568, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1811, 846, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000070559999999998, 0.000084999999999999, NULL, NULL, NULL, 'cryptopia', NULL),
(1812, 516, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1814, 1191, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1815, 515, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000010486000002007, 0.0000010750000124928, NULL, NULL, NULL, 'cryptopia', NULL),
(1817, 1192, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1818, 1193, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1819, 561, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000000048999999999936, 0.000000059999999999967, NULL, NULL, NULL, 'cryptopia', NULL),
(1820, 844, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00009235519949824, 0.000122069999744, NULL, NULL, NULL, 'cryptopia', NULL),
(1821, 1194, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1824, 579, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1830, 576, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1831, 849, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1832, 326, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1835, 606, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1837, 414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1839, 601, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1840, 416, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1841, 815, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1842, 494, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1843, 670, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1844, 307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000008036, 0.000125405, NULL, NULL, NULL, 'cryptopia', NULL),
(1845, 1204, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1846, 747, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1847, 1205, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1848, 1206, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1849, 485, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0088200098, 0.0095, NULL, NULL, NULL, 'cryptopia', NULL),
(1850, 811, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1851, 191, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1854, 1208, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1856, 951, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1857, 1209, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1860, 1211, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1861, 1212, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1863, 1214, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1864, 830, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1865, 948, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1867, 947, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000245294, 0.000337515, NULL, NULL, NULL, 'cryptopia', NULL),
(1871, 312, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1872, 650, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1873, 1216, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1874, 572, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1875, 1217, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000002058, 0.00000040499999999993, NULL, NULL, NULL, 'cryptopia', NULL),
(1876, 889, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1877, 619, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1878, 1218, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1879, 394, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000147686, 0.000117535, NULL, NULL, NULL, 'cryptopia', NULL),
(1880, 1076, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0013936286, 0.001561035, NULL, NULL, NULL, 'cryptopia', NULL),
(1881, 651, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1882, 713, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1884, 586, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1885, 1220, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1886, 850, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1887, 1221, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1888, 1222, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1889, 1223, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1890, 1224, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1892, 764, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1893, 1225, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1894, 1226, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1895, 1046, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1896, 1227, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1897, 1116, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1898, 1228, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1902, 1229, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1904, 639, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1905, 933, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1906, 319, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1908, 1231, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1910, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000065, 0.00000065, NULL, NULL, NULL, 'alcurex', NULL),
(1915, 1234, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1919, 662, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1923, 1039, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1925, 1238, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1926, 570, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000001, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1928, 1239, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1930, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.019987200016, 0.01200001, NULL, NULL, NULL, 'alcurex', NULL),
(1933, 1240, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1934, 475, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1935, 577, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1936, 1241, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1939, 1242, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1941, 530, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1943, 585, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1946, 411, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1947, 1246, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(1957, 1249, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(1960, 1252, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000002, 0.0000003, NULL, NULL, NULL, 'bitex', NULL),
(1964, 1257, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1966, 1115, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000010780000000186, 0.000003800000000021, NULL, NULL, NULL, 'cryptopia', NULL),
(1967, 1258, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1968, 478, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(1969, 1259, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1970, 1260, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1971, 308, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.000032398721599993, 0.000046524959999997, NULL, NULL, NULL, 'cryptopia', NULL),
(1972, 1103, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1973, 467, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1976, 788, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(1977, 1263, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1978, 1264, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(1979, 1265, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000019399982028276, 0.0000034200551040591, NULL, NULL, NULL, 'c-cex', NULL),
(1980, 585, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1981, 626, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1982, 796, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1983, 1080, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1984, 1266, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1985, 528, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1988, 1269, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1989, 312, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1990, 1270, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1991, 1271, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1992, 1272, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1993, 1273, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1994, 889, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1995, 1274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1996, 1275, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1997, 1276, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1998, 1277, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(1999, 1278, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2000, 1279, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2001, 1280, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2002, 1281, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2003, 1282, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2004, 1283, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2005, 1284, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2006, 1285, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2007, 1286, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2008, 1287, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2009, 768, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2010, 1288, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2011, 1289, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2012, 1290, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2013, 1263, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2014, 723, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2015, 1020, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2016, 394, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2017, 1291, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2018, 1292, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2019, 1293, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2020, 1294, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2021, 1295, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2022, 1296, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2023, 1297, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2024, 1298, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2025, 1299, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2026, 1300, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2027, 1211, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2028, 1301, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2029, 801, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2030, 662, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2031, 1302, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2032, 1303, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2033, 1304, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2034, 579, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2035, 1305, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2036, 1306, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2037, 1307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2038, 1308, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2039, 1309, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2040, 1310, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2041, 1311, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2042, 889, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2043, 1271, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2044, 1045, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2045, 1307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2046, 1274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2047, 1281, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2048, 1312, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2049, 265, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2050, 488, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2051, 1313, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2052, 187, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2053, 1278, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2054, 1305, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2055, 1314, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2056, 1279, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2057, 1291, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2058, 1315, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2059, 1274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2060, 1281, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2061, 1301, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2062, 601, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2063, 401, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2064, 1287, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2065, 909, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2066, 1306, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2067, 1316, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2068, 589, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2069, 1317, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2070, 1318, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2071, 1288, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2072, 1319, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2073, 1320, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2074, 1321, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2075, 1322, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2076, 1323, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2077, 1324, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2078, 1325, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2079, 1326, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2080, 1327, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2081, 1115, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2082, 1328, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2083, 1329, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2084, 1311, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2085, 1330, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2086, 1292, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2087, 1331, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2088, 1307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2089, 1332, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2090, 406, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2091, 1333, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2092, 1334, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2093, 1335, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2094, 1302, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2095, 1274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2096, 1336, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2097, 1337, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2098, 1338, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2099, 1339, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2100, 666, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2101, 1340, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2102, 1341, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2103, 1304, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2104, 1342, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2105, 1343, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2106, 1344, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2107, 1345, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2108, 1105, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2109, 1346, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2110, 1347, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2111, 1348, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2112, 1349, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2113, 1350, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2114, 1300, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2115, 1053, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2116, 1280, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2117, 1351, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2118, 187, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2119, 1352, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2120, 1353, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2122, 1355, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2123, 1306, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2124, 1356, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2125, 1357, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2126, 1358, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2127, 1359, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2128, 1305, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2129, 1360, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2130, 411, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2131, 1361, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2132, 485, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2133, 1362, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2134, 1310, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2135, 1363, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2136, 1364, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2137, 1365, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2138, 1366, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2139, 1367, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2140, 1368, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2141, 1361, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2142, 1274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2143, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL);
INSERT INTO `markets` (`id`, `coinid`, `disabled`, `marketid`, `priority`, `lastsent`, `lasttraded`, `balancetime`, `deleted`, `txfee`, `balance`, `ontrade`, `price`, `price2`, `pricetime`, `deposit_address`, `message`, `name`, `base_coin`) VALUES
(2144, 371, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2145, 457, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2146, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2147, 364, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2148, 308, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2149, 856, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2150, 1241, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2151, 632, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2152, 419, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2153, 893, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2154, 824, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2155, 660, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2156, 808, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2157, 591, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2158, 719, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2159, 373, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2160, 478, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2161, 823, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2162, 643, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2163, 577, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2164, 574, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2165, 722, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2166, 1369, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2167, 760, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2168, 479, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2169, 783, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2170, 392, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2171, 301, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2172, 794, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2173, 491, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2174, 394, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2175, 607, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2176, 869, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2177, 585, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2178, 305, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2179, 304, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2180, 818, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2181, 440, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2182, 346, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2183, 399, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2184, 445, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2185, 898, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2186, 1285, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2187, 705, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2188, 1002, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2189, 650, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2190, 1248, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2191, 773, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2192, 397, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2193, 1046, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2194, 1231, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2195, 1305, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2196, 1292, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2197, 1275, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2198, 1317, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2199, 299, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2200, 522, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2201, 519, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2202, 1320, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2203, 1211, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2204, 1265, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2205, 1333, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2206, 1222, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2207, 873, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2208, 1293, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2209, 815, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2210, 1277, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2211, 1294, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2212, 1339, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2213, 1341, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2214, 884, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2215, 1083, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2216, 488, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2217, 1283, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2218, 1284, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2219, 1359, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2220, 1295, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2221, 425, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2222, 1362, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2223, 737, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2224, 720, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2225, 1344, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2226, 1342, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2227, 414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2228, 662, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2229, 274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2230, 515, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2231, 659, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2232, 1297, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2233, 1356, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2234, 712, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2235, 1331, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2236, 1307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2237, 1274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2238, 1281, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2239, 589, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2240, 974, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2241, 1355, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2242, 673, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2243, 1028, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2244, 423, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2245, 722, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2246, 612, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2247, 1009, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2248, 1300, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2249, 1302, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2250, 676, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2251, 587, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2252, 1323, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2253, 1045, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2254, 1094, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2255, 1303, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2256, 570, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2257, 1233, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2258, 580, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2259, 1309, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2260, 478, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2261, 1351, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2262, 1360, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2263, 1304, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2264, 411, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2265, 1310, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2266, 1353, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2267, 428, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2268, 1271, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2269, 708, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2270, 949, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2271, 1270, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2272, 1325, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2273, 1272, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2274, 1328, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2275, 947, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2276, 991, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2277, 1076, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2278, 521, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2279, 950, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2280, 1098, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2281, 1262, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2282, 1313, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2283, 883, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2284, 1254, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2285, 1370, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2286, 346, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00011023824, 0.000114608, NULL, NULL, NULL, 'safecex', NULL),
(2287, 1371, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2288, 393, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2289, 308, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00001652672, 0.00001738, NULL, NULL, NULL, 'safecex', NULL),
(2290, 1294, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2291, 406, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000110544, 0.000001192, NULL, NULL, NULL, 'safecex', NULL),
(2292, 846, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00009220624, 0.000107552, NULL, NULL, NULL, 'safecex', NULL),
(2293, 299, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000059584, 0.000000612, NULL, NULL, NULL, 'safecex', NULL),
(2294, 421, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2295, 959, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000016464, 0.000000196, NULL, NULL, NULL, 'safecex', NULL),
(2296, 190, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00012204528, 0.00012756, NULL, NULL, NULL, 'safecex', NULL),
(2297, 1295, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2298, 1372, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2299, 893, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.01281582848, 0.0133262, NULL, NULL, NULL, 'safecex', NULL),
(2300, 1285, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2301, 338, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000000392, 0.000000048, NULL, NULL, NULL, 'safecex', NULL),
(2302, 1320, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2303, 392, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2304, 1373, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2305, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2306, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2307, 686, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2308, 502, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000136416, 0.000014328, NULL, NULL, NULL, 'safecex', NULL),
(2309, 187, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2310, 579, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2311, 1222, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2312, 485, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2313, 77, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000656208, 0.000068328, NULL, NULL, NULL, 'safecex', NULL),
(2314, 568, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2315, 1266, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2316, 577, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2317, 515, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2318, 374, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2319, 104, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2320, 304, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00006352752, 0.000087848, NULL, NULL, NULL, 'safecex', NULL),
(2321, 307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000010976, 0.000000132, NULL, NULL, NULL, 'safecex', NULL),
(2322, 654, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2323, 1374, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2324, 1298, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2325, 566, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2326, 1353, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2327, 1350, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2328, 1322, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2329, 1045, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2330, 1375, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2331, 877, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000421792, 0.000005012, NULL, NULL, NULL, 'safecex', NULL),
(2332, 865, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2333, 1376, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2334, 1094, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2335, 1377, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2336, 873, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2337, 1378, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2338, 1300, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2339, 1265, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.0000003136, 0.000000352, NULL, NULL, NULL, 'safecex', NULL),
(2340, 1379, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2341, 1305, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2342, 1380, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2343, 1381, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2344, 1382, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2345, 1383, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2346, 428, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2347, 950, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2348, 1384, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2349, 1385, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2350, 1368, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2351, 1386, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2352, 154, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2353, 557, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2354, 974, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2355, 1310, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2356, 1277, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2357, 587, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2358, 1387, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2359, 1388, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2360, 1309, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2361, 561, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2362, 1389, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2363, 1314, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2364, 1331, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2365, 1390, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2366, 594, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, 0.00000159936, 0.00000172, NULL, NULL, NULL, 'safecex', NULL),
(2367, 1076, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2369, 1347, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2370, 274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2372, 1391, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2373, 390, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2374, 612, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2375, 1187, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2376, 1266, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2377, 1392, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2378, 1378, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2379, 1393, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2380, 451, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2381, 1394, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2382, 672, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2383, 656, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2384, 708, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2385, 1395, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2386, 399, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2387, 712, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2388, 1396, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2389, 1397, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2390, 664, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2391, 482, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2392, 190, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2393, 702, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2394, 153, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2395, 1398, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2396, 585, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2397, 767, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2398, 187, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2399, 1086, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2400, 1399, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2401, 760, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2402, 440, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2403, 386, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2404, 1400, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2406, 581, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2407, 396, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2408, 1402, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2409, 1285, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2410, 104, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2411, 413, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2412, 591, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2413, 556, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2414, 1118, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2416, 528, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2417, 686, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2418, 265, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2419, 1372, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2420, 838, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2421, 692, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2422, 1404, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2423, 666, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2424, 200, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2425, 1405, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2426, 638, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2427, 192, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2428, 1020, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2429, 626, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2430, 154, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2431, 479, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2432, 873, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2433, 1406, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2434, 1407, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2435, 522, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2436, 421, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2437, 959, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2438, 1358, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2439, 1408, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2440, 1311, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2441, 884, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2442, 1409, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2444, 1382, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2445, 1302, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2446, 633, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2447, 693, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2448, 694, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2449, 657, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2451, 1283, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2452, 392, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2453, 1094, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2454, 717, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2455, 305, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2456, 1385, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2457, 400, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2458, 574, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2459, 1320, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2460, 663, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2461, 1410, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2462, 758, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2463, 960, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2464, 961, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2465, 854, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2466, 1277, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2467, 716, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2468, 1365, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2469, 577, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2470, 554, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2471, 1028, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2472, 744, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2473, 500, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2474, 1411, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2475, 457, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2476, 1307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2477, 1273, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2478, 243, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2479, 450, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2480, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'kraken', NULL),
(2481, 577, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'kraken', NULL),
(2482, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'kraken', NULL),
(2483, 1290, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'kraken', NULL),
(2484, 268, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'kraken', NULL),
(2485, 1318, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2486, 1374, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2487, 1020, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2488, 1412, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2489, 649, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2490, 1413, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2491, 392, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2492, 651, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2493, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2494, 654, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2495, 655, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2496, 657, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2497, 1080, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2498, 1274, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2499, 1340, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2500, 795, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2501, 1344, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2502, 1415, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2503, 573, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2504, 428, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2505, 579, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2506, 1416, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2507, 522, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2508, 390, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2509, 744, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2510, 1277, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2511, 718, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2512, 722, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2513, 1368, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2514, 747, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'alcurex', NULL),
(2515, 1417, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2516, 1291, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2517, 1315, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2518, 443, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2519, 760, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2520, 371, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2521, 849, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2522, 893, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2523, 1307, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2524, 406, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2525, 146, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2526, 601, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2527, 488, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2528, 155, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2529, 1418, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2530, 299, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2531, 686, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2532, 577, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2533, 585, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2534, 1306, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2535, 390, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2536, 346, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2537, 399, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2538, 874, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL),
(2539, 1373, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2540, 1377, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2541, 1376, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2542, 1370, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2543, 1399, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2544, 1372, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2545, 1406, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2546, 1371, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2547, 1394, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2548, 1390, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2549, 1391, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2550, 1413, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2551, 1375, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2552, 1381, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2553, 1374, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2554, 1379, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2555, 1382, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2556, 1385, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2557, 1380, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2558, 1383, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2559, 1389, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2560, 1386, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2561, 1387, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2562, 1392, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2563, 1400, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2564, 1378, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2565, 1419, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2566, 1318, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2567, 1420, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'cryptopia', NULL),
(2568, 1419, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2569, 1359, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2570, 356, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2571, 1335, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2572, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2573, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bleutrade', NULL),
(2574, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2575, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'c-cex', NULL),
(2576, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bter', NULL),
(2577, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2578, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2579, 1421, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2580, 1422, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2581, 1422, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2582, 1423, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2583, 1423, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2584, 1419, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'bittrex', NULL),
(2585, 1424, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2586, 1424, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'yobit', NULL),
(2587, 1288, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'poloniex', NULL),
(2588, 1357, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'safecex', NULL),
(2589, 1414, 0, NULL, 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'banx', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `mining`
--

CREATE TABLE `mining` (
  `id` int(11) NOT NULL,
  `usdbtc` double DEFAULT NULL,
  `last_monitor_exchange` int(11) DEFAULT NULL,
  `last_update_price` int(11) DEFAULT NULL,
  `last_payout` int(11) DEFAULT NULL,
  `stratumids` varchar(1024) DEFAULT NULL,
  `best_algo` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `mining`
--

INSERT INTO `mining` (`id`, `usdbtc`, `last_monitor_exchange`, `last_update_price`, `last_payout`, `stratumids`, `best_algo`) VALUES
(1, 418.82, 1422830048, 1422829644, 1459683363, '', 'lyra2');

-- --------------------------------------------------------

--
-- Structure de la table `nicehash`
--

CREATE TABLE `nicehash` (
  `id` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `last_decrease` int(11) DEFAULT NULL,
  `algo` varchar(32) DEFAULT NULL,
  `btc` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `speed` double DEFAULT NULL,
  `workers` int(11) DEFAULT NULL,
  `accepted` double DEFAULT NULL,
  `rejected` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `nicehash`
--

INSERT INTO `nicehash` (`id`, `active`, `orderid`, `last_decrease`, `algo`, `btc`, `price`, `speed`, `workers`, `accepted`, `rejected`) VALUES
(1, 0, NULL, NULL, 'x11', NULL, NULL, NULL, 0, 0, 0),
(2, 0, NULL, NULL, 'scrypt', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 0, NULL, NULL, 'sha256', NULL, NULL, NULL, NULL, NULL, NULL),
(4, 0, NULL, NULL, 'scryptn', NULL, NULL, NULL, NULL, NULL, NULL),
(5, 0, NULL, NULL, 'x13', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 0, NULL, NULL, 'x15', NULL, NULL, NULL, 0, 0, 0),
(7, 0, NULL, NULL, 'nist5', NULL, NULL, NULL, NULL, NULL, NULL),
(8, 0, NULL, NULL, 'neoscrypt', NULL, NULL, NULL, 0, 0, 0),
(9, 0, NULL, NULL, 'lyra2', NULL, NULL, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `coinid` int(11) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `ask` double DEFAULT NULL,
  `bid` double DEFAULT NULL,
  `market` varchar(16) DEFAULT NULL,
  `uuid` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `payouts`
--

CREATE TABLE `payouts` (
  `id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `account_ids` varchar(1024) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `amount` double DEFAULT NULL,
  `fee` double DEFAULT NULL,
  `tx` varchar(128) DEFAULT NULL,
  `errmsg` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `rawcoins`
--

CREATE TABLE `rawcoins` (
  `id` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `symbol` varchar(32) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `rawcoins`
--

INSERT INTO `rawcoins` (`id`, `name`, `symbol`, `active`) VALUES
(1, 'Bitcoin', 'BTC', 1),
(2, 'Litecoin', 'LTC', 1),
(3, 'Dogecoin', 'DOGE', 1),
(4, 'Vertcoin', 'VTC', 1),
(5, 'ReddCoin', 'RDD', 1),
(6, 'NXT', 'NXT', 1),
(7, 'DarkCoin', 'DRK', 1),
(8, 'PotCoin', 'POT', 1),
(9, 'BlackCoin', 'BC', 1),
(10, 'MyriadCoin', 'MYR', 1),
(12, 'OctoCoin', '888', 1),
(15, 'ElectronicGulden', 'EFL', 1),
(16, 'DimeCoin', 'DIME', 1),
(17, 'RotoCoin', 'RT2', 0),
(18, 'SolarCoin', 'SLR', 1),
(21, 'FlutterCoin ', 'FLT', 0),
(23, 'CryptoEscudoCoin', 'CESC', 1),
(24, 'PesetaCoin ', 'PTC', 1),
(25, 'IsraelCoin ', 'ISR', 1),
(26, 'CleanWaterCoin ', 'WATER', 1),
(29, 'GuldenCoin', 'NLG', 1),
(30, 'RubyCoin', 'RBY', 1),
(31, 'GiveCoin', 'GIVE', 1),
(32, 'WhiteCoin', 'WC', 1),
(34, 'MonaCoin', 'MONA', 1),
(36, 'NobleCoin', 'NOBL', 1),
(37, 'CinniCoin', 'CINNI', 0),
(38, 'BitStarCoin', 'BITS', 1),
(39, 'BlueCoin', 'BLU', 1),
(40, 'OrangeCoin', 'OC', 1),
(42, 'HempCoin', 'THC', 1),
(46, 'EnergyCoin', 'ENRG', 1),
(47, 'ShibeCoin', 'SHIBE', 1),
(49, 'SaffronCoin', 'SFR', 1),
(53, 'LibertyCoin', 'XLB', 0),
(55, 'NautilusCoin', 'NAUT', 1),
(56, 'VeriCoin', 'VRC', 1),
(57, 'CureCoin', 'CURE', 1),
(60, 'UroCoin', 'URO', 1),
(62, 'SyncCoin', 'SYNC', 1),
(64, 'BlakeCoin', 'BLC', 1),
(66, 'StabilitySharesXSI', 'XSI', 1),
(67, 'XCurrency', 'XC', 1),
(68, 'Dirac', 'XDQ', 1),
(71, 'GraniteCoin', 'GRN', 1),
(73, 'SuperCoin', 'SUPER', 1),
(74, 'JackpotCoin ', 'JPC', 1),
(76, 'Maieuticoin', 'MMXIV', 1),
(77, 'BoostCoin ', 'BOST', 0),
(78, 'CAIx', 'CAIX', 1),
(81, 'Boolberry', 'BBR', 1),
(83, 'Hyper', 'HYPER', 1),
(84, 'CannaCoin', 'CCN', 1),
(90, 'KryptKoin', 'KTK', 1),
(91, 'Mugatu', 'MUGA', 1),
(93, 'VootCoin', 'VOOT', 1),
(94, 'BankNote', 'BN', 1),
(95, 'Monero', 'XMR', 1),
(96, 'CloakCoin', 'CLOAK', 1),
(100, 'TalkCoin', 'TAC', 1),
(103, 'CHCCoin', 'CHCC', 1),
(107, 'GlyphCoin', 'GLYPH', 0),
(109, 'CoolCoin', 'COOL', 0),
(110, 'BurnerCoin', 'BURN', 1),
(112, 'CryptCoin', 'CRYPT', 1),
(115, 'StartCoin', 'START', 1),
(116, 'FractalCoin', 'FRAC', 0),
(119, 'KoreCoin', 'KORE', 1),
(122, 'Razor', 'RZR', 1),
(123, 'Guerillacoin', 'GUE', 0),
(124, 'DuckNote', 'XDN', 1),
(128, 'Minerals', 'MIN', 1),
(133, 'TechCoin', 'TECH', 1),
(135, 'CoffeeCoin', 'CFC2', 1),
(136, 'GameLeagueCoin', 'GML', 1),
(137, 'TruckCoin', 'TRK', 1),
(139, 'WankCoin', 'WKC', 1),
(143, 'Quatloo', 'QTL', 1),
(144, 'Saturn2Coin', 'SAT2', 0),
(145, 'XXXCoin', 'XXX', 1),
(151, 'AeroCoin', 'AERO', 1),
(156, 'TrustPlus', 'TRUST', 1),
(157, 'BritCoin', 'BRIT', 1),
(158, 'JudgeCoin', 'JUDGE', 1),
(159, 'NavajoCoin', 'NAV', 1),
(160, 'IcebergCoin', 'ICB', 0),
(161, 'FreshCoin', 'FRSH', 1),
(162, 'ShieldCoin', 'SHLD', 0),
(163, 'StealthCoin', 'XST', 1),
(164, 'AegisCoin', 'AGS', 0),
(168, 'ApexCoin', 'APEX', 1),
(171, 'ZetaCoin', 'ZET', 1),
(172, 'BitcoinDark', 'BTCD', 1),
(173, 'PseudoCash', 'PSEUD', 0),
(176, 'KeyCoin', 'KEY', 1),
(178, 'NewUniversalDollar', 'NUD', 1),
(180, 'ViaCoin', 'VIA', 1),
(181, 'Triangles', 'TRI', 1),
(182, 'PlanktonCoin', 'FOOD', 0),
(183, 'ConcealCoin', 'CNL', 0),
(186, 'Pesa', 'PES', 1),
(187, 'IncognitoCoin', 'ICG', 1),
(189, 'Unobtanium', 'UNO', 1),
(192, 'EsportsCoin', 'ESC', 1),
(193, 'DarkCash', 'DRKC', 0),
(198, 'PinkCoin', 'PINK', 1),
(199, 'IOCoin', 'IOC', 1),
(202, 'ShadowCash', 'SDC', 1),
(204, 'RawCoin', 'RAW', 1),
(207, 'MaxCoin', 'MAX', 1),
(208, 'LibrexCoin', 'LXC', 1),
(209, 'BoomCoin', 'BOOM', 1),
(210, 'DobbsCoin', 'BOB', 1),
(215, 'Unattainium', 'UNAT', 1),
(216, 'MultiWalletCoin', 'MWC', 1),
(217, 'CannabisCoin', 'CANN', 1),
(220, 'VaultCoin', 'VAULT', 1),
(224, 'Fuel2Coin', 'FC2', 1),
(225, 'SonicScrewDriver', 'SSD', 1),
(229, 'JoinCoin', 'J', 1),
(230, 'SoleCoin', 'SOLE', 0),
(231, 'UmbrellaLTC', 'ULTC', 1),
(233, 'SysCoin', 'SYS', 1),
(235, 'Halcyon', 'HAL', 1),
(237, 'BigBullion', 'BIG', 1),
(239, 'NeosCoin', 'NEOS', 1),
(240, 'Digibyte', 'DGB', 1),
(242, 'GreenBacks', 'GB', 1),
(243, 'RootCoin', 'ROOT', 1),
(245, 'Axron', 'AXR', 1),
(246, 'RipoffCoin', 'RIPO', 1),
(249, 'Fibre', 'FIBRE', 1),
(252, 'Nimbus', 'NMB', 1),
(253, 'ACoin', 'ACOIN', 0),
(254, 'ShadeCoin', 'SHADE', 1),
(255, 'FlexibleCoin', 'FLEX', 1),
(256, 'CoinMarketsCoin', 'JBS', 1),
(257, 'SSVCoin', 'SSV', 0),
(258, 'SocialXBot', 'XBOT', 1),
(259, 'XCash', 'XCASH', 1),
(260, 'BURST', 'BURST', 1),
(262, 'LitecoinDark', 'LTCD', 1),
(263, 'LightSpeed', 'LSD', 0),
(264, 'BancorCoin', 'BNCR', 0),
(265, 'CraigsCoin', 'CRAIG', 1),
(266, 'TitCoin', 'TIT', 1),
(267, 'GlobalBoost-Y', 'BSTY', 1),
(268, 'Gnosis', 'GNS', 1),
(269, 'VolatilityCoin', 'VLTY', 1),
(270, 'DeepCoin', 'DCN', 1),
(271, 'Prime-XI', 'PXI', 1),
(272, 'MozzShare', 'MLS', 1),
(273, 'CrackCoin', 'CRACK', 0),
(274, 'DigitalCoin', 'DGC', 1),
(275, 'Bitmark', 'BTM', 1),
(278, 'CoinWorksCoin', 'LAB', 0),
(279, 'SterlingCoin', 'SLG', 1),
(280, 'DarkToken', 'DT', 0),
(281, 'RosCoin', 'ROS', 1),
(282, '42Coin', '42', 0),
(283, 'AsiaCoin', 'AC', 0),
(284, 'AlphaCoin', 'ALF', 0),
(285, 'AlienCoin', 'ALN', 0),
(286, 'AmericanCoin', 'AMC', 0),
(287, 'AnonCoin', 'ANC', 1),
(288, 'Argentum', 'ARG', 0),
(289, 'AuroraCoin', 'AUR', 0),
(290, 'BattleCoin', 'BCX', 0),
(291, 'Benjamins', 'BEN', 0),
(292, 'Betacoin', 'BET', 0),
(293, 'BBQCoin', 'BQC', 0),
(294, 'BitBar', 'BTB', 0),
(295, 'ByteCoin', 'BTE', 0),
(296, 'BitGem', 'BTG', 0),
(297, 'CryptoBuck', 'BUK', 0),
(298, 'CACHeCoin', 'CACH', 0),
(299, 'BottleCaps', 'CAP', 0),
(300, 'CashCoin', 'CASH', 0),
(301, 'CatCoin', 'CAT', 0),
(302, 'CryptogenicBullion', 'CGB', 0),
(303, 'CopperLark', 'CLR', 1),
(304, 'Cosmoscoin', 'CMC', 0),
(305, 'CHNCoin', 'CNC', 0),
(306, 'CommunityCoin', 'COMM', 0),
(307, 'CraftCoin', 'CRC', 0),
(308, 'CasinoCoin', 'CSC', 0),
(309, 'eMark', 'DEM', 0),
(310, 'Diamond', 'DMD', 0),
(311, 'DevCoin', 'DVC', 0),
(312, 'EarthCoin', 'EAC', 0),
(313, 'ElaCoin', 'ELC', 0),
(314, 'Einsteinium', 'EMC2', 0),
(315, 'Emerald', 'EMD', 0),
(316, 'ExeCoin', 'EXE', 0),
(317, 'EZCoin', 'EZC', 0),
(318, 'FireflyCoin', 'FFC', 0),
(319, 'FreiCoin', 'FRC', 1),
(320, 'Franko', 'FRK', 0),
(321, 'FastCoin', 'FST', 0),
(322, 'FeatherCoin', 'FTC', 1),
(323, 'GrandCoin', 'GDC', 0),
(324, 'Globalcoin', 'GLC', 0),
(325, 'GoldCoin', 'GLD', 0),
(326, 'Galaxycoin', 'GLX', 0),
(327, 'HoboNickels', 'HBN', 0),
(328, 'HunterCoin', 'HUC', 0),
(329, 'HeavyCoin', 'HVC', 0),
(330, 'InfiniteCoin', 'IFC', 1),
(331, 'IXCoin', 'IXC', 0),
(332, 'JunkCoin', 'JKC', 0),
(333, 'KlondikeCoin', 'KDC', 0),
(334, 'KrugerCoin', 'KGC', 0),
(335, 'LegendaryCoin', 'LGD', 0),
(336, 'Lucky7Coin', 'LK7', 0),
(337, 'LuckyCoin', 'LKY', 0),
(338, 'LiteBar', 'LTB', 0),
(339, 'LiteCoinX', 'LTCX', 0),
(340, 'LycanCoin', 'LYC', 0),
(341, 'MegaCoin', 'MEC', 1),
(342, 'Mediterraneancoin', 'MED', 0),
(343, 'MintCoin', 'MINT', 1),
(346, 'MinCoin', 'MNC', 0),
(347, 'MurrayCoin', 'MRY', 0),
(348, 'MazaCoin', 'MZC', 0),
(349, 'NanoToken', 'NAN', 0),
(350, 'Nibble', 'NBL', 0),
(351, 'NeoCoin', 'NEC', 0),
(352, 'Netcoin', 'NET', 1),
(353, 'NameCoin', 'NMC', 1),
(354, 'NoirBits', 'NRB', 0),
(355, 'NoirShares', 'NRS', 0),
(356, 'NovaCoin', 'NVC', 0),
(357, 'NyanCoin', 'NYAN', 0),
(358, 'Orbitcoin', 'ORB', 1),
(359, 'OpenSourceCoin', 'OSC', 0),
(360, 'PhilosopherStone', 'PHS', 0),
(361, 'CryptsyPoints', 'Points', 0),
(362, 'Peercoin', 'PPC', 1),
(363, 'Bitshares PTS', 'PTS', 0),
(364, 'PhoenixCoin', 'PXC', 0),
(365, 'PayCoin', 'PYC', 0),
(366, 'Quark', 'QRK', 1),
(367, 'RonPaulCoin', 'RPC', 0),
(368, 'RoyalCoin', 'RYC', 0),
(369, 'StableCoin', 'SBC', 0),
(370, 'SilkCoin', 'SILK', 0),
(371, 'SmartCoin', 'SMC', 0),
(372, 'SpainCoin', 'SPA', 0),
(373, 'Spots', 'SPT', 0),
(374, 'SecureCoin', 'SRC', 0),
(375, 'StarCoin', 'STR', 0),
(376, 'SexCoin', 'SXC', 1),
(377, 'TagCoin', 'TAG', 0),
(378, 'TakCoin', 'TAK', 0),
(379, 'TekCoin', 'TEK', 0),
(380, 'TeslaCoin', 'TES', 0),
(381, 'TigerCoin', 'TGC', 0),
(382, 'TorCoin', 'TOR', 0),
(383, 'TerraCoin', 'TRC', 0),
(384, 'UnbreakableCoin', 'UNB', 0),
(385, 'USDe', 'USDe', 0),
(386, 'UltraCoin', 'UTC', 1),
(387, 'WorldCoin', 'WDC', 1),
(388, 'Crypti', 'XCR', 0),
(389, 'JouleCoin', 'XJO', 0),
(390, 'PrimeCoin', 'XPM', 1),
(391, 'YaCoin', 'YAC', 0),
(392, 'YBCoin', 'YBC', 0),
(393, 'ZcCoin', 'ZCC', 0),
(394, 'ZedCoin', 'ZED', 0),
(395, 'AndroidsTokensV2', 'ADT', 0),
(396, 'AsicCoin', 'ASC', 0),
(397, 'BatCoin', 'BAT', 0),
(398, 'ColossusCoin', 'COL', 0),
(399, 'CopperBars', 'CPR', 0),
(400, 'Continuumcoin', 'CTM', 0),
(401, 'Doubloons', 'DBL', 0),
(402, 'DamaCoin', 'DMC', 0),
(403, 'ElephantCoin', 'ELP', 0),
(404, 'FlappyCoin', 'FLAP', 0),
(405, 'FlorinCoin', 'FLO', 0),
(406, 'GameCoin', 'GME', 0),
(407, 'KarmaCoin', 'KARM', 1),
(408, 'LeafCoin', 'LEAF', 0),
(409, 'LottoCoin', 'LOT', 0),
(410, 'MemeCoin', 'MEM', 0),
(411, 'KittehCoin', 'MEOW', 0),
(412, 'MoonCoin', 'MOON', 1),
(413, 'MasterCoin (Hydro)', 'MST', 0),
(414, 'RabbitCoin', 'RBBT', 0),
(415, 'RedCoin', 'RED', 0),
(416, 'FedoraCoin', 'TIPS', 0),
(417, 'Tickets', 'TIX', 0),
(418, 'XenCoin', 'XNC', 0),
(419, 'ZeitCoin', 'ZEIT', 0),
(420, '', 'ABC2', 0),
(421, '', 'AID', 0),
(424, '', 'BTQ', 0),
(426, '', 'CHILD', 1),
(428, 'Checkcoin', 'CKC', 1),
(437, '', 'GRC', 0),
(438, '', 'IMAC', 0),
(440, 'Lemurcoin', 'LMR', 1),
(441, '', 'MOTO', 0),
(442, '', 'MSC', 0),
(444, '', 'NIC', 0),
(445, '', 'NOTE', 0),
(446, '', 'NWO', 0),
(447, '', 'ONE', 1),
(448, 'OpalCoin', 'OPAL', 1),
(450, '', 'PLCN', 0),
(452, '', 'PROZ', 0),
(453, 'PyramidsCoin', 'PYRA', 1),
(460, 'SativaCoin', 'STV', 1),
(467, '', 'XRC', 0),
(468, '', 'XSX', 0),
(469, '', 'CCI', 0),
(470, '', 'GHC', 1),
(471, 'Bleutrade Share', 'BLEU', 1),
(473, 'BeaverCoin', 'BVC', 1),
(474, 'Canada eCoin', 'CDN', 1),
(475, 'CzechCrownCoin', 'CZC', 1),
(476, 'Donationcoin', 'DON', 1),
(477, 'FujiCoin', 'FJC', 1),
(478, 'GCoin', 'GCN', 1),
(479, 'Guncoin', 'GUN', 1),
(480, 'HamRadioCoin', 'HAM', 1),
(481, 'HeisenbergHex', 'HEX', 1),
(482, 'HTML5', 'HTML5', 1),
(483, 'IrishCoin', 'IRL', 1),
(484, 'NewYorkCoin', 'NYC', 1),
(485, 'Paccoin', 'PAC', 1),
(486, 'PolishCoin', 'PCC', 1),
(487, 'PHCoin', 'PHC', 1),
(488, 'Pandacoin', 'PND', 1),
(489, 'POWcoin', 'POW', 1),
(490, 'RussiaCoin', 'RC', 1),
(494, 'TrollCoin', 'TRL', 1),
(495, 'US Dollar', 'USD', 1),
(497, 'VirtaCoin', 'VTA', 1),
(498, 'InkwayCoin', 'LKNX', 1),
(503, 'ExclusiveCoin', 'EXCL', 1),
(505, 'EtherCoin', 'ETC', 1),
(506, 'VikingCoin', 'VIK', 1),
(507, 'XG', 'XG', 1),
(513, 'MaryJaneCoin', 'MARYJ', 1),
(516, 'unknown', 'SONG', 0),
(517, 'Magi', 'XMG', 1),
(518, 'UtilityCoin', 'UTIL', 1),
(519, 'Ruble', 'RUBLE', 1),
(520, 'Wolfcoin', 'WLF', 1),
(521, 'XCloudCoin', 'XCLD', 1),
(522, 'BitSwift', 'SWIFT', 1),
(525, 'ArchCoin', 'ARCH', 1),
(526, 'GhostCoin', 'GHOST', 1),
(527, 'SeedCoin', 'SEED', 1),
(530, 'GAIACoin', 'GAIA', 1),
(531, 'WorldWideCoin', 'WWC', 1),
(532, 'Cagecoin', 'CAGE', 1),
(533, 'Ripple', 'XRP', 0),
(534, 'WhistleCoin', 'WSTL', 1),
(537, 'Munne', 'MNE', 1),
(538, 'unknown', 'CRW', 0),
(539, 'unknown', 'SQC', 0),
(541, 'unknown', 'VOXP', 0),
(542, 'EquinoxCoin ', 'EQX', 1),
(544, 'GlowCoin', 'GLOW', 1),
(545, 'unknown', 'KRYP', 0),
(547, 'unknown', 'PLCS', 0),
(548, 'unknown', 'VTX', 0),
(549, 'MiracleCoin', 'MCL', 1),
(550, 'DopeCoin', 'DOPE', 1),
(552, 'unknown', 'DOGEB', 0),
(553, 'unknown', 'SPUDS', 0),
(554, 'VidioShare', 'VDO', 1),
(555, 'CamorraCoin', 'CAM', 1),
(556, 'NopeCoin', 'NOPE', 1),
(557, 'SparkCoin', 'SPARK', 1),
(558, 'unknown', 'UP', 0),
(560, 'CannabisDarkcoin', 'CND', 1),
(561, 'DogeCoinDark', 'DOGED', 1),
(562, 'MetalMusicCoin', 'MTLMC', 1),
(563, 'MonetaryUnit', 'MUE', 1),
(564, 'GanjaCoin', 'GANJA', 1),
(565, 'DayTraderCoin', 'DTC', 1),
(567, 'ScatterCoin', 'XSTC', 1),
(568, 'Sembro Token', 'SMBR', 1),
(569, 'CleverHash', 'CHASH', 1),
(570, 'DarkShibe', 'DSB', 1),
(571, 'HyperStake', 'HYP', 0),
(572, 'unknown', 'LOG', 0),
(573, 'unknown', 'QBK', 0),
(574, 'DigitalPrice', 'DP', 1),
(575, 'Bladecoin', 'BLA', 1),
(576, 'DarkKush', 'DANK', 1),
(578, 'Pennies', 'CENT', 0),
(579, 'BlockNet', 'BLOCK', 1),
(580, 'unknown', 'CATC', 0),
(581, 'unknown', 'VOCAL', 0),
(582, 'SecuritySysCoin', 'SCSY', 1),
(583, 'AppleBytes', 'ABY', 1),
(584, 'unknown', 'MIC', 0),
(585, 'Snowballs', 'BALLS', 1),
(586, 'RektCoin', 'REKT', 1),
(587, 'Quicksilver', 'QSLV', 1),
(588, 'unknown', 'ICNX', 0),
(590, 'unknown', 'U', 0),
(592, 'ByteCent', 'BYC', 1),
(593, 'BunnyCoin', 'BUN', 1),
(594, 'UroDark', 'UROD', 1),
(595, 'UFOCoin', 'UFO', 1),
(596, 'unknown', 'ZER', 0),
(597, 'EthereumDark', 'ETD', 1),
(598, 'Nanite', 'XNAN', 1),
(600, 'OcupyCoin', 'OCUPY', 1),
(601, 'unknown', 'ZNY', 0),
(602, 'unknown', 'FICE', 0),
(603, 'unknown', 'HLC', 0),
(604, 'Guarany', 'GUA', 1),
(605, 'unknown', 'ACHK', 0),
(606, 'unknown', 'GIMP', 0),
(607, 'unknown', 'BOARD', 0),
(608, 'GlowShares', 'GSX', 1),
(609, 'unknown', 'PFC', 0),
(610, 'Quotient', 'XQN', 1),
(611, 'OptimumCoin', 'OPTI', 1),
(612, 'Consolidated Mining', 'MN', 0),
(613, 'GreenCoin', 'GRE', 1),
(614, 'VPNCoin', 'VPN', 1),
(615, 'Bollywoodcoin', 'BDC', 1),
(616, 'ViorCoin', 'VIOR', 1),
(617, 'BitBay', 'BAY', 1),
(618, 'HawaiiCoin', 'HIC', 1),
(619, 'MalibuCoin', 'MAL', 1),
(620, 'ImperiumCoin', 'IMPC', 1),
(621, 'Diode', 'DIO', 1),
(622, 'DeafDollars', 'DEAF', 1),
(623, 'unknown', 'ALI', 0),
(624, 'BitSharesX', 'BTS', 1),
(625, 'unknown', 'EUPH', 0),
(626, 'WorldTradeFunds', 'XWT', 1),
(627, 'MobCoin', 'MOB', 1),
(628, 'PimpCash', 'PIMP', 1),
(629, 'unknown', 'ERM', 0),
(630, 'MewnCoin', 'MEWN', 1),
(631, 'unknown', 'FUD', 0),
(632, 'unknown', 'KING', 0),
(633, 'AeroME', 'AM', 1),
(634, 'unknown', 'FIND', 0),
(635, 'unknown', 'CBR', 0),
(636, 'SpreadCoin', 'SPR', 1),
(637, 'MetalCoin', 'METAL', 1),
(638, 'CheckOutCoin', 'CXC', 1),
(639, 'BitcoinFast', 'BCF', 1),
(640, 'unknown', 'STB', 0),
(641, 'unknown', 'RMS', 0),
(642, 'EventCoint', 'EVENT', 1),
(644, 'FairCoin', 'FAIR', 1),
(645, 'DarkSwift', 'DS', 1),
(646, 'unknown', 'BCENT', 0),
(647, 'unknown', 'SMLY', 0),
(648, 'PayCoin', 'XPY', 1),
(649, 'NooCoin', 'NOO', 1),
(650, 'vTorrent', 'VTR', 1),
(651, 'Clams', 'CLAM', 0),
(652, 'TittieCoin', 'TTC', 0),
(653, 'Sapience', 'XAI', 1),
(654, 'NakomotoDark', 'NKT', 1),
(655, 'Ideacoin', 'IDC', 1);

-- --------------------------------------------------------

--
-- Structure de la table `renters`
--

CREATE TABLE `renters` (
  `id` int(11) NOT NULL,
  `created` int(11) DEFAULT NULL,
  `updated` int(11) DEFAULT NULL,
  `address` varchar(1024) DEFAULT NULL,
  `email` varchar(1024) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `apikey` varbinary(1024) DEFAULT NULL,
  `received` double DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `unconfirmed` double DEFAULT NULL,
  `spent` double DEFAULT NULL,
  `custom_start` double DEFAULT NULL,
  `custom_balance` double DEFAULT NULL,
  `custom_accept` double DEFAULT NULL,
  `custom_reject` double DEFAULT NULL,
  `custom_address` varchar(1024) DEFAULT NULL,
  `custom_server` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `rentertxs`
--

CREATE TABLE `rentertxs` (
  `id` int(11) NOT NULL,
  `renterid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `address` varchar(1024) DEFAULT NULL,
  `tx` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `servers`
--

CREATE TABLE `servers` (
  `id` int(11) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `maxcoins` int(11) DEFAULT NULL,
  `uptime` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `algo` varchar(64) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `speed` bigint(20) DEFAULT NULL,
  `custom_balance` double DEFAULT NULL,
  `custom_accept` double DEFAULT NULL,
  `custom_reject` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `services`
--

INSERT INTO `services` (`id`, `name`, `algo`, `price`, `speed`, `custom_balance`, `custom_accept`, `custom_reject`) VALUES
(1, 'Nicehash', 'scrypt', 0.0003646, 20628000000, 0, 0, 0),
(2, 'Nicehash', 'x11', 0.0004524, 15616000000, 0, 0, 0),
(3, 'Nicehash', 'x13', 0.0003273, 185100000, 0, 0, 0),
(4, 'Nicehash', 'x15', 0.0004079, 7200000, 0, 0, 0),
(5, 'Nicehash', 'nist5', 0.001, 21900000, 0, 0, 0),
(6, 'Nicehash', 'sha256', 0.0000098, 2310347791200000, 0, 0, 0),
(7, 'Nicehash', 'scryptn', 0.0005521, 1200000, 0, 0, 0),
(8, 'Nicehash', 'neoscrypt', 0.0073366, 13600000, 0, 0, 0),
(9, 'Nicehash', 'lyra2', 0.0006123, 181400000, 0, 0, 0),
(16, 'Nicehash', 'qubit', 0.0001968, 72200000, 0, 0, 0),
(17, 'Nicehash', 'quark', 0.0004536, 65978400000, 0, 0, 0),
(18, 'Nicehash', 'zr5', 0.0001, 61865000000, 0, 0, 0),
(19, 'Nicehash', 'c11', 0.0003403, 11823800000, 0, 0, 0),
(20, 'Nicehash', 'keccak', 0.0000027, 153200000, 0, 0, 0),
(21, 'Nicehash', 'whirlx', 0.0000091, 1100700000, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `shares`
--

CREATE TABLE `shares` (
  `id` bigint(30) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `workerid` int(11) DEFAULT NULL,
  `coinid` int(11) DEFAULT NULL,
  `jobid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `error` int(11) DEFAULT NULL,
  `valid` tinyint(1) DEFAULT NULL,
  `extranonce1` tinyint(1) DEFAULT NULL,
  `difficulty` double NOT NULL DEFAULT '0',
  `share_diff` double NOT NULL DEFAULT '0',
  `algo` varchar(16) DEFAULT 'x11'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `stats`
--

CREATE TABLE `stats` (
  `id` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `profit` double DEFAULT NULL,
  `wallet` double DEFAULT NULL,
  `wallets` double DEFAULT NULL,
  `immature` double DEFAULT NULL,
  `margin` double DEFAULT NULL,
  `waiting` double DEFAULT NULL,
  `balances` double DEFAULT NULL,
  `onsell` double DEFAULT NULL,
  `renters` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `stats`
--

INSERT INTO `stats` (`id`, `time`, `profit`, `wallet`, `wallets`, `immature`, `margin`, `waiting`, `balances`, `onsell`, `renters`) VALUES
(382, 1459692900, 0, 0, NULL, NULL, 0, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `stratums`
--

CREATE TABLE `stratums` (
  `pid` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `algo` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `withdraws`
--

CREATE TABLE `withdraws` (
  `id` int(11) NOT NULL,
  `market` varchar(1024) DEFAULT NULL,
  `address` varchar(1024) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `uuid` varchar(1024) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `workers`
--

CREATE TABLE `workers` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `subscribe` tinyint(1) DEFAULT NULL,
  `difficulty` double DEFAULT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `dns` varchar(1024) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `nonce1` varchar(64) DEFAULT NULL,
  `version` varchar(64) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `worker` varchar(64) DEFAULT NULL,
  `algo` varchar(16) DEFAULT 'scrypt'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `coin` (`coinid`),
  ADD KEY `balance` (`balance`),
  ADD KEY `earning` (`last_earning`);

--
-- Index pour la table `algos`
--
ALTER TABLE `algos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Index pour la table `balances`
--
ALTER TABLE `balances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Index pour la table `balanceuser`
--
ALTER TABLE `balanceuser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `time` (`time`);

--
-- Index pour la table `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `time` (`time`),
  ADD KEY `algo1` (`algo`),
  ADD KEY `coin` (`coin_id`),
  ADD KEY `category` (`category`),
  ADD KEY `user1` (`userid`),
  ADD KEY `height1` (`height`);

--
-- Index pour la table `coins`
--
ALTER TABLE `coins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auto_ready` (`auto_ready`),
  ADD KEY `enable` (`enable`),
  ADD KEY `algo` (`algo`),
  ADD KEY `symbol` (`symbol`),
  ADD KEY `index_avg` (`index_avg`),
  ADD KEY `created` (`created`);

--
-- Index pour la table `connections`
--
ALTER TABLE `connections`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `earnings`
--
ALTER TABLE `earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`userid`),
  ADD KEY `coin` (`coinid`),
  ADD KEY `block` (`blockid`),
  ADD KEY `create1` (`create_time`),
  ADD KEY `status` (`status`);

--
-- Index pour la table `exchange`
--
ALTER TABLE `exchange`
  ADD PRIMARY KEY (`id`),
  ADD KEY `coinid` (`coinid`),
  ADD KEY `status` (`status`),
  ADD KEY `market` (`market`),
  ADD KEY `send_time` (`send_time`);

--
-- Index pour la table `hashrate`
--
ALTER TABLE `hashrate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t1` (`time`),
  ADD KEY `a1` (`algo`);

--
-- Index pour la table `hashrenter`
--
ALTER TABLE `hashrenter`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `hashstats`
--
ALTER TABLE `hashstats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `algo1` (`algo`),
  ADD KEY `time1` (`time`);

--
-- Index pour la table `hashuser`
--
ALTER TABLE `hashuser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u1` (`userid`),
  ADD KEY `t1` (`time`),
  ADD KEY `a1` (`algo`);

--
-- Index pour la table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `renterid` (`renterid`),
  ADD KEY `ready` (`ready`),
  ADD KEY `active` (`active`),
  ADD KEY `algo` (`algo`),
  ADD KEY `price` (`price`);

--
-- Index pour la table `jobsubmits`
--
ALTER TABLE `jobsubmits`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `markets`
--
ALTER TABLE `markets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `coinid` (`coinid`),
  ADD KEY `name` (`name`),
  ADD KEY `lastsent` (`lastsent`),
  ADD KEY `lasttraded` (`lasttraded`);

--
-- Index pour la table `mining`
--
ALTER TABLE `mining`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `nicehash`
--
ALTER TABLE `nicehash`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `coinid` (`coinid`),
  ADD KEY `created` (`created`),
  ADD KEY `market` (`market`);

--
-- Index pour la table `payouts`
--
ALTER TABLE `payouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`,`completed`);

--
-- Index pour la table `rawcoins`
--
ALTER TABLE `rawcoins`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `renters`
--
ALTER TABLE `renters`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `rentertxs`
--
ALTER TABLE `rentertxs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `renterid` (`renterid`),
  ADD KEY `time` (`time`);

--
-- Index pour la table `servers`
--
ALTER TABLE `servers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name1` (`name`);

--
-- Index pour la table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `shares`
--
ALTER TABLE `shares`
  ADD PRIMARY KEY (`id`),
  ADD KEY `time` (`time`),
  ADD KEY `algo1` (`algo`),
  ADD KEY `valid1` (`valid`),
  ADD KEY `user1` (`userid`),
  ADD KEY `worker1` (`workerid`),
  ADD KEY `coin1` (`coinid`),
  ADD KEY `jobid` (`jobid`);

--
-- Index pour la table `stats`
--
ALTER TABLE `stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `time` (`time`);

--
-- Index pour la table `stratums`
--
ALTER TABLE `stratums`
  ADD PRIMARY KEY (`pid`);

--
-- Index pour la table `withdraws`
--
ALTER TABLE `withdraws`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `workers`
--
ALTER TABLE `workers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `algo1` (`algo`),
  ADD KEY `name1` (`name`),
  ADD KEY `userid` (`userid`),
  ADD KEY `pid` (`pid`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `algos`
--
ALTER TABLE `algos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `balances`
--
ALTER TABLE `balances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `balanceuser`
--
ALTER TABLE `balanceuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `coins`
--
ALTER TABLE `coins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `earnings`
--
ALTER TABLE `earnings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `exchange`
--
ALTER TABLE `exchange`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `hashrate`
--
ALTER TABLE `hashrate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `hashrenter`
--
ALTER TABLE `hashrenter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `hashstats`
--
ALTER TABLE `hashstats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `hashuser`
--
ALTER TABLE `hashuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `jobsubmits`
--
ALTER TABLE `jobsubmits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `markets`
--
ALTER TABLE `markets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `mining`
--
ALTER TABLE `mining`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `nicehash`
--
ALTER TABLE `nicehash`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `payouts`
--
ALTER TABLE `payouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `rawcoins`
--
ALTER TABLE `rawcoins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `renters`
--
ALTER TABLE `renters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `rentertxs`
--
ALTER TABLE `rentertxs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `servers`
--
ALTER TABLE `servers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `shares`
--
ALTER TABLE `shares`
  MODIFY `id` bigint(30) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `stats`
--
ALTER TABLE `stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `withdraws`
--
ALTER TABLE `withdraws`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `workers`
--
ALTER TABLE `workers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
